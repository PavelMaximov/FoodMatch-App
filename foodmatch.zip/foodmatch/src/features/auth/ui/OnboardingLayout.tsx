import { Box, Typography } from "@mui/material";
import type { ReactNode } from "react";
import logoFoodmatch from "../../../assets/media/logofmwhitenotext.png";


type Props = {
  backgroundUrl: string;
  titleTop?: string;
  subtitleTop?: string;
  children: ReactNode;
};

export function OnboardingLayout({
  backgroundUrl,
  titleTop = "Foodmatch",
  subtitleTop,
  children,
}: Props) {
  return (
    <Box
      sx={{
        position: "fixed",
        inset: 0,
        overflow: "hidden",
        bgcolor: "#000",
      }}
    >
      {/* Background */}
      <Box
        sx={{
          position: "absolute",
          inset: 0,
          backgroundImage: `url(${backgroundUrl})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          transform: "scale(1.02)",
        }}
      />

      {/* Readability overlay */}
      <Box
        sx={{
          position: "absolute",
          inset: 0,
          background:
            "linear-gradient(0deg, rgba(0,0,0,0) 0%,  rgba(0, 0, 0, 0.3) 80%, rgba(0, 0, 0, 0.75) 100%)", 
          }}
      />

      {/* Header */}
      <Box
        sx={{
          position: "absolute",
          top: 28,
          left: 0,
          right: 0,
          zIndex: 2,
          px: 3,
          textAlign: "center",
          color: "white",
          pointerEvents: "none",
        }}
      >

        <Box sx={{ display: "flex", justifyContent: "center", mb: 1 }}>
          <img src={logoFoodmatch} alt="Foodmatch Logo" height={48} />
          </Box>

          <Typography
            sx={{
              fontFamily: `"Pacifico", cursive`,
              fontSize: 42,
              lineHeight: 1,
              
            }}
          >
            {titleTop}
          </Typography>

          {subtitleTop && (
            <Typography
              sx={{
                mt: 1.2,
                fontSize: 15,
                lineHeight: 1.35,
                color: "rgba(255,255,255,0.85)",
                maxWidth: 360,
                mx: "auto",
              }}
            >
              {subtitleTop}
            </Typography>
          )}
        </Box>

        {/* Bottom sheet */}
        <Box
          sx={{
            position: "absolute",
            left: 0,
            right: 0,
            bottom: 0,
            zIndex: 3,
            pt: "calc(14px + env(safe-area-inset-bottom))",
            
          }}
        >
          <Box
            sx={{
              width: "100%",
              borderTopLeftRadius: 22,
              borderTopRightRadius: 22,
              bgcolor: "rgba(10,10,10,0.92)",
              backdropFilter: "blur(8px)",
              boxShadow: "0 -18px 40px rgba(0,0,0,0.45)",
              px: 6,
              pt: 3.5,
              pb: 3.5,
            }}
          >
            {children}
          </Box>
        </Box>
      </Box>
      );
}
