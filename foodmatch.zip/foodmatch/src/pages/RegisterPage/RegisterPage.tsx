import { Box, Divider, TextField, Typography, FormControlLabel, Checkbox, useMediaQuery } from "@mui/material";
import { useTheme } from "@mui/material/styles";
import { useState } from "react";
import { useNavigate, Link as RouterLink } from "react-router-dom";

import { useAuth } from "../../features/auth/model/useAuth";
import { AuthCard } from "../../features/auth/ui/AuthCard";
import { AuthOAuthButtons } from "../../features/auth/ui/AuthOAuthButtons";
import { PrimaryButton } from "../../shared/ui/PrimaryButton";

import { OnboardingLayout } from "../../features/auth/ui/OnboardingLayout";
import {
  OnboardingTitle,
  OnboardingTextField,
  OnboardingPrimaryButton,
  OnboardingDivider,
  OnboardingOAuthRow,
  OnboardingBottomCTA,
} from "../../features/auth/ui/OnboardingAuthUI";

import BG_URL from "../../assets/media/onboarding.jpg";


export function RegisterPage() {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("md"));

  if (isMobile) {
    return <MobileRegisterView />;
  }

  return <DesktopRegisterView />;
}

// --------------------
// DESKTOP
// --------------------
function DesktopRegisterView() {
  const { register, isLoading } = useAuth();
  const nav = useNavigate();

  const [displayName, setDisplayName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [agree, setAgree] = useState(true);

  async function onSubmit() {
    await register({ email, password, displayName });
    nav("/swipe");
  }

  return (
    <AuthCard>
      
      <Typography sx={{ fontFamily: `"Pacifico", cursive`, fontSize: 34, lineHeight: 1, mb: 2.5 }}>
        Register on <span style={{ color: "#FF5D1D" }}>Foodmatch</span>
      </Typography>

      <AuthOAuthButtons googleText="Continue with Google" appleText="Continue with Apple" />

      <Divider sx={{ my: 2.6, color: "rgba(16,17,19,0.30)" }}>Or</Divider>

      <Box sx={{ display: "flex", flexDirection: "column", gap: 1.6 }}>
        <TextField
          value={displayName}
          onChange={(e) => setDisplayName(e.target.value)}
          placeholder="* Display name"
          InputProps={{ sx: { borderRadius: 3 } }}
        />

        <TextField
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="* Email"
          InputProps={{ sx: { borderRadius: 3 } }}
        />

        <TextField
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="* Password (min 6)"
          type="password"
          InputProps={{ sx: { borderRadius: 3 } }}
        />

        <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mt: 0.5 }}>
          <FormControlLabel
            control={<Checkbox checked={agree} onChange={(e) => setAgree(e.target.checked)} />}
            label={<Typography sx={{ fontWeight: 700 }}>I agree with Terms</Typography>}
          />

          <Typography
            component={RouterLink}
            to="/login"
            sx={{ fontWeight: 800, color: "#49426C", textDecoration: "none" }}
          >
            Already have an account?
          </Typography>
        </Box>

        <PrimaryButton onClick={onSubmit} disabled={isLoading || !agree} sx={{ mt: 1 }}>
          Create account
        </PrimaryButton>

        <Typography sx={{ textAlign: "center", mt: 1.5, fontWeight: 800, color: "#49426C" }}>
          <Typography component={RouterLink} to="/login" sx={{ color: "inherit", textDecoration: "none" }}>
            Back to Login
          </Typography>
        </Typography>
      </Box>
    </AuthCard>
  );
}

// --------------------
// MOBILE 
// --------------------
function MobileRegisterView() {
  const { register, isLoading } = useAuth();
  const nav = useNavigate();

  const [displayName, setDisplayName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  async function onSubmit() {
    await register({ email, password, displayName });
    nav("/swipe");
  }

  return (
    <OnboardingLayout
      backgroundUrl={BG_URL}
      titleTop="Foodmatch"
      subtitleTop="Create an account and start matching dishes together."
    >
      <OnboardingTitle left="Register on" accent="Foodmatch" />

      <Box sx={{ display: "flex", flexDirection: "column", gap: 1.6 }}>
        <OnboardingTextField
          value={displayName}
          onChange={(e) => setDisplayName(e.target.value)}
          placeholder="* Display name"
          autoComplete="name"
        />

        <OnboardingTextField
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="* Email"
          autoComplete="email"
        />

        <OnboardingTextField
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="* Password (min 6)"
          type="password"
          autoComplete="new-password"
        />

        <OnboardingPrimaryButton onClick={onSubmit} disabled={isLoading}>
          Create account
        </OnboardingPrimaryButton>

        <OnboardingDivider />
        <OnboardingOAuthRow />

        <RouterLink to="/login" style={{ textDecoration: "none" }}>
          <OnboardingBottomCTA>
            Already have an account? <span style={{ color: "#FF5D1D", marginLeft: "6px" }}>Log in</span>
          </OnboardingBottomCTA>
        </RouterLink>
      </Box>
    </OnboardingLayout>
  );
}
