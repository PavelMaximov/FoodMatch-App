import {
  Box,
  Card,
  CardContent,
  Typography,
  TextField,
  Button,
  Stack,
  Alert,
} from "@mui/material";
import { useEffect, useRef, useState } from "react";

import AddRoundedIcon from "@mui/icons-material/AddRounded";
import AttachFileRoundedIcon from "@mui/icons-material/AttachFileRounded";

import { AddDishSuccess } from "./AddDishSuccess";
import { createDishApi } from "../../dishes/api/dishes.api";
import { uploadImage } from "../../uploads/api/upload.api";

type Props = {
  onDishCreated: () => void;
};

type FormState = {
  title: string;
  kitchen: string;
  description: string;
  imageUrl: string; // можно оставить для будущего "вставить ссылку", сейчас не используем в UI
};

const initialState: FormState = {
  title: "",
  kitchen: "",
  description: "",
  imageUrl: "",
};

const FALLBACK_IMAGE =
  "https://images.unsplash.com/photo-1490474418585-ba9bad8fd0ea?auto=format&fit=crop&w=1400&q=80";

export function AddDishForm({ onDishCreated }: Props) {
  const [form, setForm] = useState<FormState>(initialState);
  const [showSuccess, setShowSuccess] = useState(false);

  const [submitting, setSubmitting] = useState(false);
  const [errorText, setErrorText] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  function setField<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  function validate(): string | null {
    if (!form.title.trim()) return "Введите название блюда";
    if (!form.kitchen.trim()) return "Введите кухню / стиль";
    if (!form.description.trim()) return "Добавьте описание";
    return null;
  }

  function onPickFile() {
    fileInputRef.current?.click();
  }

  function onFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0] ?? null;
    if (!file) return;

    // базовая валидация файла
    if (!file.type.startsWith("image/")) {
      setErrorText("Можно прикреплять только изображения");
      return;
    }

    const maxMb = 5;
    if (file.size > maxMb * 1024 * 1024) {
      setErrorText(`Файл слишком большой. Максимум ${maxMb}MB`);
      return;
    }

    setErrorText(null);

    // если ранее был previewUrl — освобождаем, чтобы не текла память
    setPreviewUrl((prev) => {
      if (prev) URL.revokeObjectURL(prev);
      return prev;
    });

    setSelectedFile(file);
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);

    // важно: чтобы можно было выбрать тот же файл повторно
    e.target.value = "";
  }

  async function handleSubmit() {
    if (submitting) return;

    const err = validate();
    if (err) {
      setErrorText(err);
      return;
    }

    setSubmitting(true);
    setErrorText(null);

    try {
      let imageUrl = form.imageUrl.trim() || FALLBACK_IMAGE;

      // если выбрали файл — сначала upload, потом используем url
      if (selectedFile) {
        imageUrl = await uploadImage(selectedFile);
      }

      await createDishApi({
        title: form.title.trim(),
        description: form.description.trim(),
        imageUrl,
        cuisine: form.kitchen.trim(),
        tags: [],
      });

      // сброс формы
      setForm(initialState);
      setSelectedFile(null);
      setPreviewUrl((prev) => {
        if (prev) URL.revokeObjectURL(prev);
        return null;
      });

      setShowSuccess(true);
      onDishCreated();
    }  catch (e: unknown) {
      const errorMessage = e instanceof Error ? e.message : "Не удалось добавить блюдо";
      setErrorText(errorMessage);
    } finally {
      setSubmitting(false);
    }
  }

  // автоскрытие success оверлея
  useEffect(() => {
    if (!showSuccess) return;
    const t = window.setTimeout(() => setShowSuccess(false), 1600);
    return () => window.clearTimeout(t);
  }, [showSuccess]);

  // cleanup на размонтирование (если остался previewUrl)
  useEffect(() => {
    return () => {
      if (previewUrl) URL.revokeObjectURL(previewUrl);
    };
  }, [previewUrl]);

  return (
    <Card sx={{ position: "relative" }}>
      <CardContent sx={{ p: 3 }}>
        {/* Header */}
        <Box sx={{ display: "flex", alignItems: "center", gap: 1.2, mb: 1 }}>
          <Box
            sx={{
              width: 22,
              height: 22,
              borderRadius: "50%",
              background: "#FF5D1D",
              display: "grid",
              placeItems: "center",
              flex: "0 0 auto",
            }}
          >
            <AddRoundedIcon sx={{ color: "white", fontSize: 16 }} />
          </Box>

          <Typography
            sx={{
              fontSize: 30,
              lineHeight: 1,
              fontFamily: `"Pacifico", cursive`,
            }}
          >
            Add your dish
          </Typography>
        </Box>

        <Typography sx={{ color: "rgba(16,17,19,0.55)", mb: 2 }}>
          Your ideas are automatically added to the deck and are available to both participants.
        </Typography>

        {errorText && (
          <Alert severity="warning" sx={{ mb: 2, borderRadius: 3 }}>
            {errorText}
          </Alert>
        )}

        <Stack spacing={1.3}>
          <TextField
            placeholder="* Name of the dish"
            value={form.title}
            onChange={(e) => setField("title", e.target.value)}
            InputProps={{
              sx: { borderRadius: 3, background: "#F2F2F2" },
            }}
          />

          <TextField
            placeholder="* Kitchen / style"
            value={form.kitchen}
            onChange={(e) => setField("kitchen", e.target.value)}
            InputProps={{
              sx: { borderRadius: 3, background: "#F2F2F2" },
            }}
          />

          <TextField
            placeholder="* Description"
            value={form.description}
            onChange={(e) => setField("description", e.target.value)}
            multiline
            minRows={3}
            InputProps={{
              sx: {
                borderRadius: 3,
                background: "#F2F2F2",
                alignItems: "flex-start",
              },
            }}
          />

          {/* Attach */}
          <Box sx={{ display: "flex", alignItems: "center", gap: 1, mt: 1 }}>
            <Button
              variant="text"
              onClick={onPickFile}
              startIcon={<AttachFileRoundedIcon />}
              sx={{
                fontWeight: 900,
                color: "#49426C",
                textTransform: "none",
                p: 0,
                "&:hover": { background: "transparent", opacity: 0.9 },
              }}
              disabled={submitting}
            >
              Attach photo
            </Button>

            {selectedFile && (
              <Typography
                sx={{
                  color: "rgba(16,17,19,0.55)",
                  fontWeight: 700,
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  whiteSpace: "nowrap",
                  minWidth: 0,
                  flex: 1,
                }}
                title={selectedFile.name}
              >
                {selectedFile.name}
              </Typography>
            )}

            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              hidden
              onChange={onFileChange}
            />
          </Box>

          {previewUrl && (
            <Box
              sx={{
                mt: 1.5,
                borderRadius: 4,
                overflow: "hidden",
                border: "1px solid rgba(16,17,19,0.10)",
              }}
            >
              <img src={previewUrl} alt="preview" style={{ width: "100%", display: "block" }} />
            </Box>
          )}

          {/* Submit */}
          <Button
            onClick={handleSubmit}
            startIcon={<AddRoundedIcon />}
            disabled={submitting}
            sx={{
              mt: 0.5,
              py: 1.3,
              borderRadius: 999,
              color: "white",
              background: "linear-gradient(90deg,#FB4B11,#FF5D1D)",
              boxShadow: "none",
              "&:hover": {
                background: "linear-gradient(90deg,#FB4B11,#FF5D1D)",
                opacity: 0.95,
                boxShadow: "none",
              },
            }}
          >
            {submitting ? "Saving..." : "Save to deck"}
          </Button>
        </Stack>
      </CardContent>

      {/* Success overlay */}
      {showSuccess && <AddDishSuccess onClose={() => setShowSuccess(false)} />}
    </Card>
  );
}
