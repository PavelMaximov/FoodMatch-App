import { CssBaseline, ThemeProvider as MuiThemeProvider, createTheme } from "@mui/material";
import type { ReactNode } from "react";

const theme = createTheme({
    typography: {
        fontFamily: `"Nunito", system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif`,
        h4: { fontWeight: 900 },
        h5: { fontWeight: 900 },
        h6: { fontWeight: 900 },
    },
    shape: {
        borderRadius: 6,
    },
    components: {
        MuiCard: {
            styleOverrides: {
                root: {
                    borderRadius: 22,
                    boxShadow: "0 12px 40px rgba(0,0,0,0.10)",
                    "& .MuiOutlinedInput-notchedOutline": {
                        borderColor: "rgba(0,0,0,0.10)",
                    },
                    "&:hover .MuiOutlinedInput-notchedOutline": {
                        borderColor: "rgba(0,0,0,0.14)",
                    },
                    "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
                        borderColor: "rgba(0,0,0,0.18)",
                    },
                },
            },
        },
        MuiButton: {
            styleOverrides: {
                root: {
                    textTransform: "none",
                    borderRadius: 999,
                    fontWeight: 800,
                },
            },
        },
        MuiChip: {
            styleOverrides: {
                root: {
                    borderRadius: 999,
                    fontWeight: 700,
                },
            },
        },
    },
});

type Props = { children: ReactNode };

export function ThemeProvider({ children }: Props) {
    return (
        <MuiThemeProvider theme={theme}>
            <CssBaseline />
            {children}
        </MuiThemeProvider>
    );
}
