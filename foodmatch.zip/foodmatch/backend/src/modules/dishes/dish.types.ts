export type RecipeStep = {
  title: string;
  text: string;
};

export type Recipe = {
  ingredients: string[];
  steps: RecipeStep[];
};
