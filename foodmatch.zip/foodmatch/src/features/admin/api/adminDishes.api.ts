import type { DishDTO } from "../../dishes/api/dishes.api";

const API_URL = import.meta.env.VITE_API_URL ?? "http://localhost:4000";
const ADMIN_TOKEN = import.meta.env.VITE_ADMIN_TOKEN ?? "";

function adminHeaders() {
  return {
    "Content-Type": "application/json",
    "x-admin-token": ADMIN_TOKEN,
  };
}

export type RecipeStepDTO = { title: string; text: string };

export type DishInputDTO = {
  title: string;
  description: string;
  imageUrl: string;
  cuisine: string;
  tags: string[];
  source?: string;

  recipe?: {
    serves?: number | null;
    totalTimeMin?: number | null;
    ingredients: string[];
    steps: RecipeStepDTO[];
  } | null;
};

export async function adminListDishesApi(): Promise<{ dishes: DishDTO[] }> {
  const res = await fetch(`${API_URL}/api/dishes`);
  if (!res.ok) throw new Error("Failed to load dishes");
  return res.json();
}

export async function adminGetDishApi(id: string): Promise<{ dish: unknown }> {
  const res = await fetch(`${API_URL}/api/dishes/${id}`);
  if (!res.ok) throw new Error("Failed to load dish");
  return res.json();
}

export async function adminCreateDishApi(payload: DishInputDTO): Promise<{ dish: unknown }> {
  const res = await fetch(`${API_URL}/api/dishes`, {
    method: "POST",
    headers: adminHeaders(),
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error("Failed to create dish");
  return res.json();
}

export async function adminUpdateDishApi(id: string, payload: Partial<DishInputDTO>): Promise<{ dish: unknown }> {
  const res = await fetch(`${API_URL}/api/dishes/${id}`, {
    method: "PATCH",
    headers: adminHeaders(),
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error("Failed to update dish");
  return res.json();
}

export async function adminDeleteDishApi(id: string): Promise<{ ok: true }> {
  const res = await fetch(`${API_URL}/api/dishes/${id}`, {
    method: "DELETE",
    headers: adminHeaders(),
  });
  if (!res.ok) throw new Error("Failed to delete dish");
  return res.json();
}
