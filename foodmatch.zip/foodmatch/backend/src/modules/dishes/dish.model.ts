import mongoose, { Schema, model } from "mongoose";

const RecipeStepSchema = new Schema(
  {
    title: { type: String, required: true, trim: true },
    text: { type: String, required: true, trim: true },
  },
  { _id: false }
);

const RecipeSchema = new Schema(
  {
    serves: { type: Number, default: null },
    totalTimeMin: { type: Number, default: null },

    ingredients: { type: [String], default: [] },

    steps: { type: [RecipeStepSchema], default: [] },
  },
  { _id: false }
);

const DishSchema = new Schema(
  {
    title: { type: String, required: true, trim: true },
    description: { type: String, required: true, trim: true },
    imageUrl: { type: String, required: true },

    cuisine: { type: String, required: true, trim: true },

    tags: { type: [String], default: [] },

    source: { type: String, default: "manual" },
    createdBy: { type: Schema.Types.ObjectId, ref: "User", default: null },

    recipe: { type: RecipeSchema, default: null },
  },
  { timestamps: true }
);

export const Dish = model("Dish", DishSchema);
