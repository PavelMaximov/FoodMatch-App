export function makeId(prefix = "id"): string {
  // Простой id для демо: dish_1700000000000_ab12cd
  const rand = Math.random().toString(16).slice(2, 8);
  return `${prefix}_${Date.now()}_${rand}`;
}
