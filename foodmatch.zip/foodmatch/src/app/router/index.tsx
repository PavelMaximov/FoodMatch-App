import { createBrowserRouter, Navigate } from "react-router-dom";
import { AppLayout } from "../ui/AppLayout";
import { AuthLayout } from "../layouts/AuthLayout";
import { SwipePage } from "../../pages/SwipePage/SwipePage";
import { LoginPage } from "../../pages/LoginPage/LoginPage";
import { RegisterPage } from "../../pages/RegisterPage/RegisterPage";
import { ProtectedRoute } from "./ProtectedRoute";
import { ForgotPasswordPage } from "../../pages/ForgotPasswordPage/ForgotPasswordPage";
import { RecipePage } from "../../pages/RecipePage/RecipePage";
import { AdminDishesPage } from "../../pages/Admin/AdminDishesPage";



export const router = createBrowserRouter([
  // AUTH (центр)
  {
    path: "/",
    element: <AuthLayout />,
    children: [
      { index: true, element: <Navigate to="/login" replace /> },
      { path: "login", element: <LoginPage /> },
      { path: "register", element: <RegisterPage /> },
      { path: "forgot-password", element: <ForgotPasswordPage /> },
    ],
  },
   {
  path: "/admin/dishes",
  element: <AdminDishesPage />,
},

  // APP (левый край)
  {
    path: "/",
    element: <AppLayout />,
    children: [
      {
        path: "swipe",
        element: (
          <ProtectedRoute>
            <SwipePage />
          </ProtectedRoute>
        ),
      },
      {
        path: "recipe/:dishId",
        element: (
          <ProtectedRoute>
            <RecipePage />
          </ProtectedRoute>
        ),
      },
    ],
  },
]);
