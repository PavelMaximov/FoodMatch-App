import { Button } from "@mui/material";
import type { ButtonProps } from "@mui/material";

export function PrimaryButton(props: ButtonProps) {
  return (
    <Button
      {...props}
      sx={{
        py: 1.4,
        borderRadius: 3,
        color: "white",
        fontWeight: 900,
        background: "linear-gradient(90deg,#FB4B11,#FF5D1D)",
        boxShadow: "none",
        "&:hover": {
          background: "linear-gradient(90deg,#FB4B11,#FF5D1D)",
          opacity: 0.95,
          boxShadow: "none",
        },
        ...props.sx,
      }}
    />
  );
}
