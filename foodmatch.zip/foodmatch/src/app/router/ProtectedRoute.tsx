import type { ReactNode } from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "../../features/auth/model/useAuth";

export function ProtectedRoute({ children }: { children: ReactNode }) {
  const { isAuthed, isLoading } = useAuth();

  if (isLoading) return null; // позже сделаю красивый loader
  if (!isAuthed) return <Navigate to="/login" replace />;

  return children;
}
