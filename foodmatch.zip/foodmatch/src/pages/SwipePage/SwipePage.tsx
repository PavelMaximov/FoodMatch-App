import React, { useEffect, useMemo, useState } from "react";
import {
  Grid,
  Typography,
  Button,
  Box,
  useMediaQuery,
  Drawer,
  IconButton,
} from "@mui/material";
import CloseRoundedIcon from "@mui/icons-material/CloseRounded";
import { useTheme } from "@mui/material/styles";

import type { Dish } from "../../entities/dish/model/types";
import { useSwipeDeck } from "../../features/swipe/ui/model/useSwipeDeck";
import { SwipeCard } from "../../features/swipe/ui/SwipeCard";
import { CoupleSession } from "../../features/matches/ui/CoupleSession";
import { AddDishForm } from "../../features/add-dish/ui/AddDishForm";

import { recordSwipeApi, matchesApi } from "../../features/swipe/api/swipes.api";
import { debounce } from "../../shared/utils/debounce";

import { ConnectSessionDialog } from "../../features/couples/ui/ConnectSessionDialog";
import { useCoupleSession } from "../../features/couples/model/useCoupleSession";

import { MatchScreen } from "../../features/matches/ui/MatchScreen";
import { MobileBottomBar, type MobileTab } from "../../shared/ui/MobileBottomNav";

import { listDishesApi, type DishDTO } from "../../features/dishes/api/dishes.api";

function mapDish(dto: DishDTO): Dish {
  return {
    id: dto._id,
    title: dto.title,
    description: dto.description,
    imageUrl: dto.imageUrl,
    tags: [dto.cuisine, ...dto.tags],
    createdBy: dto.createdBy ?? undefined,
  };
}

export function SwipePage() {
  const [dishes, setDishes] = useState<Dish[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [matches, setMatches] = useState<Dish[]>([]);

  const { session, loading: sessionLoading } = useCoupleSession();
  const [connectOpen, setConnectOpen] = useState(false);

  // Match screen
  const [matchOpen, setMatchOpen] = useState(false);
  const [matchDish, setMatchDish] = useState<{ title: string; imageUrl: string } | null>(null);
  const [prevMatchesCount, setPrevMatchesCount] = useState(0);

  // Mobile bottom sheet
  const [tab, setTab] = useState<MobileTab>("connect");
  const [sheetOpen, setSheetOpen] = useState(false);

  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("md"));

  const partnerName = useMemo(() => {
    if (!session || session.status !== "active") return "Partner";

    // Обычно members: [you, partner] или просто [you] пока один
    const m = session.members ?? [];
    if (m.length >= 2) return m[1]?.displayName || m[m.length - 1]?.displayName || "Partner";
    return m[0]?.displayName || "Partner";
  }, [session]);

  const sessionText = useMemo(() => {
    if (sessionLoading) return "Session...";
    if (!session || session.status === "none") return "Not connected";

    const count = session.members?.length ?? 0;
    if (count >= 2) return "Connected 2/2";
    return "Waiting 1/2";
  }, [session, sessionLoading]);

  async function loadMatchesOnly() {
    try {
      const m = await matchesApi();
      setMatches(m.matches.map(mapDish));
    } catch {
      // если пользователь еще не в паре или второй не подключен — молчим
    }
  }

  const debouncedRefresh = useMemo(
    () =>
      debounce(() => {
        loadMatchesOnly();
      }, 600),
    []
  );

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const res = await listDishesApi();
      setDishes(res.dishes.map(mapDish));
    } catch (e: unknown) {
      const errorMessage = e instanceof Error ? e.message : "Failed to load dishes";
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    loadMatchesOnly();
  }, []);

  // если сменили/подключили пару — обновляем матчи
  useEffect(() => {
    const handler = () => {
      setMatches([]);
      loadMatchesOnly();
    };
    window.addEventListener("foodmatch:sessionChanged", handler);
    return () => window.removeEventListener("foodmatch:sessionChanged", handler);
  }, []);

  const deck = useMemo(() => dishes, [dishes]);

  const swipe = useSwipeDeck(deck, {
    onSwipe: async ({ dish, action }) => {
      try {
        await recordSwipeApi({ dishId: dish.id, action });
        debouncedRefresh();
      } catch {
        // позже toast
      }
    },
  });

  useEffect(() => {
    if (!isMobile) return;

    // первый прогон — просто запоминаем
    if (prevMatchesCount === 0) {
      setPrevMatchesCount(matches.length);
      return;
    }

    if (matches.length > prevMatchesCount) {
      // если сервер возвращает newest первым — подойдет [0]
      const newest = matches[0] ?? matches[matches.length - 1];
      if (newest) {
        setMatchDish({ title: newest.title, imageUrl: newest.imageUrl });
        setMatchOpen(true);

        setSheetOpen(false);
      }
    }

    setPrevMatchesCount(matches.length);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [matches.length, isMobile]);

  // -----------------------
  // Loading / Error / Empty
  // -----------------------
  if (loading) {
    return <Typography sx={{ color: "white" }}>Loading dishes...</Typography>;
  }

  if (error) {
    return (
      <Box>
        <Typography sx={{ color: "white", mb: 2 }}>Error: {error}</Typography>
        <Button variant="contained" onClick={load}>
          Retry
        </Button>
      </Box>
    );
  }

  if (dishes.length === 0) {
    return (
      <Box>
        <Typography sx={{ color: "white", mb: 2 }}>No dishes in database yet.</Typography>
        <Typography sx={{ color: "rgba(255,255,255,0.7)" }}>
          На бэке можно импортировать блюда из TheMealDB.
        </Typography>
      </Box>
    );
  }

  // -----------------------
  // MOBILE
  // -----------------------
  if (isMobile) {
    const openSheetForTab = (next: MobileTab) => {
      setTab(next);
      setSheetOpen(true);
    };

    const closeSheet = () => setSheetOpen(false);

    const sheetTitle =
      tab === "connect" ? "Connect" : tab === "matches" ? "Matches" : tab === "add" ? "Add dish" : "Profile";

    return (
      <Box
        sx={{
          position: "fixed",
          inset: 0,
          overflow: "hidden",
          backgroundColor: "#000",
        }}
      >
        {/* SwipeCard */}
        <SwipeCard
          swipe={swipe}
          connectedLabel={sessionText}
          onConnectClick={() => setConnectOpen(true)}
        />

        {/* Диалог connect */}
        <ConnectSessionDialog
          open={connectOpen}
          onClose={() => setConnectOpen(false)}
        />

        {/* Экран совпадения */}
        <MatchScreen
          open={matchOpen && !!matchDish}
          dishTitle={matchDish?.title ?? ""}
          dishImageUrl={matchDish?.imageUrl ?? ""}
          otherUserName={partnerName}
          onContinue={() => {
            setMatchOpen(false);
            setMatchDish(null);
          }}
          onGoToResults={() => {
            setMatchOpen(false);
            setMatchDish(null);
            setTab("matches");     
            setSheetOpen(true);    
          }}
        />

        {/* Нижний бар */}
        <MobileBottomBar
          value={tab}
          onChange={openSheetForTab}
          matchesBadge={matches.length}
        />

        {/* Bottom-sheet поверх SwipeCard */}
        <Drawer
          anchor="bottom"
          open={sheetOpen}
          onClose={closeSheet}
          ModalProps={{ keepMounted: true }}
          PaperProps={{
            sx: {
              borderTopLeftRadius: 22,
              borderTopRightRadius: 22,
              minHeight: "42vh",
              maxHeight: "78vh",
              overflow: "hidden",
            },
          }}
        >
          {/* Header sheet */}
          <Box
            sx={{
              px: 2,
              py: 1.25,
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              borderBottom: "1px solid rgba(0,0,0,0.08)",
              backgroundColor: "rgba(255,255,255,0.98)",
            }}
          >
            <Box sx={{ fontWeight: 800, fontSize: 16 }}>{sheetTitle}</Box>

            <IconButton onClick={closeSheet} aria-label="close">
              <CloseRoundedIcon />
            </IconButton>
          </Box>

          {/* Content sheet */}
          <Box sx={{ p: 2, overflow: "auto", backgroundColor: "rgba(255,255,255,0.98)" }}>
            {tab === "connect" && (
              <Box>
                <Button
                  variant="outlined"
                  onClick={() => setConnectOpen(true)}
                  sx={{
                    mb: 2,
                    borderRadius: 999,
                    textTransform: "none",
                    fontWeight: 800,
                  }}
                >
                  Open connect dialog
                </Button>

                <CoupleSession totalLikes={swipe.totalLikes} matches={matches} />
              </Box>
            )}

            {tab === "matches" && (
              <CoupleSession totalLikes={swipe.totalLikes} matches={matches} />
            )}

            {tab === "add" && (
              <AddDishForm onDishCreated={load} />
            )}

            {tab === "profile" && (
              <Box sx={{ color: "rgba(0,0,0,0.7)", fontWeight: 600 }}>
                Profile screen будет позже, когда ты дашь макет.
              </Box>
            )}
          </Box>
        </Drawer>
      </Box>
    );
  }

  // -----------------------
  // DESKTOP 
  // -----------------------
  return (
    <Grid container spacing={3}>
      <Grid size={{ xs: 12, md: 7 }}>
        <SwipeCard
          swipe={swipe}
          connectedLabel={sessionText}
          onConnectClick={() => setConnectOpen(true)}
        />

        <ConnectSessionDialog
          open={connectOpen}
          onClose={() => setConnectOpen(false)}
        />
      </Grid>

      <Grid size={{ xs: 12, md: 5 }}>
        <Grid container spacing={3}>
          <Grid size={{ xs: 12 }}>
            <CoupleSession totalLikes={swipe.totalLikes} matches={matches} />
          </Grid>
          <Grid size={{ xs: 12 }}>
            <AddDishForm onDishCreated={load} />
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  );
}
