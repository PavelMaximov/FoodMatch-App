import {
  Box,
  Button,
  Card,
  CardContent,
  Chip,
  Typography,
  IconButton,
} from "@mui/material";
import ArrowBackIosNewRoundedIcon from "@mui/icons-material/ArrowBackIosNewRounded";
import CloseRoundedIcon from "@mui/icons-material/CloseRounded";
import LocalFireDepartmentRoundedIcon from "@mui/icons-material/LocalFireDepartmentRounded";
import SportsScoreIcon from "@mui/icons-material/SportsScore";
import { motion } from "framer-motion";

import logoFoodmatch from "../../../assets/media/logofmblack1.svg";

type Dish = {
  imageUrl: string;
  title: string;
  description: string;
  tags: string[];
};

type Props = {
  currentDish: Dish | null | undefined;
  nextDish: Dish | null | undefined;
  isFinished: boolean;

  connectedLabel?: string;
  onConnectClick: () => void;

  canSwipe: boolean;
  canGoBack: boolean;

  motionStyle: {
    x: number;
    rotate: number;
    opacity: number;
  };

  backCardStyle: {
    backScale: number;
    backY: number;
    backOpacity: number;
  };

  likeNopeStyle: {
    likeOpacity: number;
    nopeOpacity: number;
    likeY: number;
    nopeY: number;
  };

  onDragEnd: () => void;
  onSwipeLeft: () => void;
  onSwipeRight: () => void;
  onPrevious: () => void;
  onReset: () => void;
};

export function SwipeCardDesktop(props: Props) {
  const {
    currentDish,
    nextDish,
    isFinished,
    connectedLabel,
    onConnectClick,
    canSwipe,
    canGoBack,
    motionStyle,
    backCardStyle,
    likeNopeStyle,
    onDragEnd,
    onSwipeLeft,
    onSwipeRight,
    onPrevious,
    onReset,
  } = props;

  const { x, rotate, opacity } = motionStyle;
  const { backScale, backY, backOpacity } = backCardStyle;
  const { likeOpacity, nopeOpacity, likeY, nopeY } = likeNopeStyle;

  return (
    <Box sx={{ position: "relative" }}>
      {/* Back card */}
      {!isFinished && nextDish && (
        <motion.div
          style={{
            position: "absolute",
            inset: 0,
            zIndex: 0,
            scale: backScale,
            y: backY,
            opacity: backOpacity,
            pointerEvents: "none",
          }}
        >
          <Box sx={{ filter: "saturate(0.95)" }}>
            <Card>
              <CardContent sx={{ p: 3 }}>
                <Box
                  component="img"
                  src={nextDish.imageUrl}
                  alt={nextDish.title}
                  sx={{
                    width: "100%",
                    height: 420,
                    objectFit: "cover",
                    borderRadius: 4,
                    display: "block",
                    background: "rgba(0,0,0,0.06)",
                  }}
                />

                <Box sx={{ mt: 2, display: "flex", gap: 2 }}>
                  <Box sx={{ flex: 1, minWidth: 0 }}>
                    <Typography variant="h5" fontWeight={900} sx={{ lineHeight: 1.1 }}>
                      {nextDish.title}
                    </Typography>
                    <Typography color="text.secondary" sx={{ mt: 1 }}>
                      {nextDish.description}
                    </Typography>
                  </Box>

                  <Box
                    sx={{
                      width: 170,
                      display: "flex",
                      flexWrap: "wrap",
                      gap: 1,
                      alignContent: "flex-start",
                      justifyContent: "flex-start",
                    }}
                  >
                    {nextDish.tags.map((tag) => (
                      <Chip
                        key={tag}
                        label={tag}
                        variant="outlined"
                        sx={{ borderColor: "#737679", color: "#737679" }}
                      />
                    ))}
                  </Box>
                </Box>
              </CardContent>
            </Card>
          </Box>
        </motion.div>
      )}

      {/* Front card */}
      <motion.div
        style={{
          x,
          rotate,
          opacity,
          touchAction: "pan-y",
          position: "relative",
          zIndex: 1,
        }}
        drag={canSwipe ? "x" : false}
        dragConstraints={{ left: 0, right: 0 }}
        dragElastic={0.15}
        onDragEnd={onDragEnd}
      >
        <Card>
          <CardContent sx={{ p: 3 }}>
            {/* Header */}
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                mb: 2.25,
              }}
            >
              <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                <Box component="img" src={logoFoodmatch} alt="Foodmatch" sx={{ height: 28, width: "auto" }} />
                <Typography
                  sx={{
                    fontFamily: "pacifico, cursive",
                    fontSize: 24,
                    fontWeight: 700,
                    color: "#1A1A1A",
                  }}
                >
                  Foodmatch
                </Typography>
              </Box>

              <Box sx={{ display: "flex", gap: 1.25, alignItems: "center" }}>
                <Chip
                  label={connectedLabel}
                  variant="outlined"
                  sx={{
                    height: 32,
                    borderRadius: 999,
                    borderWidth: 1.7,
                    borderColor: "rgba(0,0,0,0.50)",
                    bgcolor: "#fff",
                    fontWeight: 600,
                    color: "rgba(0,0,0,0.50)",
                    px: 0.5,
                  }}
                />
                <Button
                  variant="outlined"
                  onClick={onConnectClick}
                  sx={{
                    height: 32,
                    borderRadius: 999,
                    borderWidth: 1.7,
                    textTransform: "none",
                    fontWeight: 700,
                    borderColor: "#FB4B11",
                    color: "#FB4B11",
                    px: 2.2,
                    "&:hover": {
                      borderColor: "#FB4B11",
                      bgcolor: "rgba(251,75,17,0.06)",
                    },
                  }}
                >
                  Connect session
                </Button>
              </Box>
            </Box>

            {/* Content */}
            {isFinished ? (
              <Box
                sx={{
                  height: 420,
                  display: "grid",
                  placeItems: "center",
                  textAlign: "center",
                }}
              >
                <Box>
                  <SportsScoreIcon sx={{ fontSize: 64, color: "#FF5D1D" }} />
                  <Typography variant="h6" fontWeight={900}>
                    Deck finished
                  </Typography>
                  <Typography color="text.secondary">Click Reset to start over.</Typography>
                </Box>
              </Box>
            ) : (
              <>
                {/* Image + overlays */}
                <Box sx={{ position: "relative", mb: 2.25 }}>
                  <Box
                    component="img"
                    src={currentDish?.imageUrl}
                    alt={currentDish?.title}
                    sx={{
                      width: "100%",
                      height: 420,
                      objectFit: "cover",
                      borderRadius: 4,
                      display: "block",
                      userSelect: "none",
                      pointerEvents: "none",
                    }}
                  />

                  {/* NOPE */}
                  <motion.div
                    style={{
                      position: "absolute",
                      top: 18,
                      left: 18,
                      opacity: nopeOpacity,
                      y: nopeY,
                      pointerEvents: "none",
                    }}
                  >
                    <Box
                      sx={{
                        px: 2,
                        py: 0.6,
                        borderRadius: 2,
                        border: "2px solid #49426C",
                        color: "#49426C",
                        background: "rgba(255,255,255,0.85)",
                        fontWeight: 900,
                        letterSpacing: 2,
                        fontSize: 18,
                        transform: "rotate(-10deg)",
                        display: "inline-block",
                      }}
                    >
                      NOPE
                    </Box>
                  </motion.div>

                  {/* LIKE */}
                  <motion.div
                    style={{
                      position: "absolute",
                      top: 18,
                      right: 18,
                      opacity: likeOpacity,
                      y: likeY,
                      pointerEvents: "none",
                    }}
                  >
                    <Box
                      sx={{
                        px: 2,
                        py: 0.6,
                        borderRadius: 2,
                        border: "2px solid #FF5D1D",
                        color: "#FF5D1D",
                        background: "rgba(255,255,255,0.85)",
                        fontWeight: 900,
                        letterSpacing: 2,
                        fontSize: 18,
                        transform: "rotate(10deg)",
                        display: "inline-block",
                      }}
                    >
                      LIKE
                    </Box>
                  </motion.div>

                  {/* Previous */}
                  <Button
                    variant="outlined"
                    size="small"
                    startIcon={<ArrowBackIosNewRoundedIcon sx={{ fontSize: 16 }} />}
                    onClick={onPrevious}
                    disabled={!canGoBack}
                    sx={{
                      position: "absolute",
                      left: 18,
                      bottom: 18,
                      height: 34,
                      borderRadius: 999,
                      textTransform: "none",
                      fontWeight: 700,
                      borderColor: "rgba(255,255,255,0.75)",
                      color: "rgba(255,255,255,0.95)",
                      bgcolor: "rgba(0,0,0,0.25)",
                      backdropFilter: "blur(8px)",
                      px: 2.2,
                      "&:hover": { bgcolor: "rgba(0,0,0,0.33)" },
                    }}
                  >
                    Previous
                  </Button>

                  {/* Reset */}
                  <Button
                    size="small"
                    onClick={onReset}
                    sx={{
                      position: "absolute",
                      right: 18,
                      bottom: 18,
                      height: 34,
                      borderRadius: 999,
                      textTransform: "none",
                      fontWeight: 800,
                      px: 4,
                      color: "rgba(255,255,255,0.95)",
                      bgcolor: "#5C4B5C",
                      "&:hover": { bgcolor: "#534253" },
                    }}
                  >
                    Reset
                  </Button>

                  {/* Action buttons */}
                  <Box
                    sx={{
                      position: "absolute",
                      left: 0,
                      right: 0,
                      bottom: 35,
                      display: "flex",
                      justifyContent: "center",
                      gap: 2,
                      pointerEvents: "none",
                    }}
                  >
                    <Box sx={{ pointerEvents: "auto", display: "flex", gap: 2 }}>
                      <IconButton
                        onClick={onSwipeLeft}
                        sx={{
                          width: 56,
                          height: 56,
                          bgcolor: "#fff",
                          boxShadow: "0 14px 30px rgba(0,0,0,.18)",
                          "&:hover": { bgcolor: "#fff", opacity: 0.95 },
                        }}
                      >
                        <CloseRoundedIcon sx={{ color: "#2B2B2B" }} />
                      </IconButton>

                      <IconButton
                        onClick={onSwipeRight}
                        sx={{
                          width: 56,
                          height: 56,
                          color: "white",
                          bgcolor: "#FB4B11",
                          boxShadow: "0 14px 30px rgba(0,0,0,.22)",
                          "&:hover": { bgcolor: "#FB4B11", opacity: 0.95 },
                        }}
                      >
                        <LocalFireDepartmentRoundedIcon />
                      </IconButton>
                    </Box>
                  </Box>
                </Box>

                {/* Bottom info */}
                <Box sx={{ display: "flex", gap: 2 }}>
                  <Box sx={{ flex: 1, minWidth: 0 }}>
                    <Typography variant="h5" fontWeight={900} sx={{ lineHeight: 1.1 }}>
                      {currentDish?.title}
                    </Typography>
                    <Typography color="text.secondary" sx={{ mt: 1 }}>
                      {currentDish?.description}
                    </Typography>
                  </Box>

                  <Box
                    sx={{
                      width: 170,
                      display: "flex",
                      flexWrap: "wrap",
                      gap: 1,
                      alignContent: "flex-start",
                      justifyContent: "flex-start",
                    }}
                  >
                    {currentDish?.tags.map((tag: string) => (
                      <Chip
                        key={tag}
                        label={tag}
                        variant="outlined"
                        sx={{ borderColor: "#737679", color: "#737679" }}
                      />
                    ))}
                  </Box>
                </Box>
              </>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </Box>
  );
}
