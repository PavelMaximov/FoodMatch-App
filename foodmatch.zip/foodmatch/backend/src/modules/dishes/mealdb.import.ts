import { Dish } from "./dish.model.js";

const BASE = "https://www.themealdb.com/api/json/v1/1";

type MealDbMeal = {
  idMeal: string;
  strMeal: string;
  strMealThumb: string;
  strInstructions: string;
  strArea: string;
  strTags: string | null;
};

export async function importMealDbRandom(count: number) {
  const tasks = Array.from({ length: count }, () => fetch(`${BASE}/random.php`).then((r) => r.json()));
  const results = await Promise.all(tasks);

  let inserted = 0;

  for (const r of results) {
    const meal: MealDbMeal | undefined = r?.meals?.[0];
    if (!meal) continue;

    const exists = await Dish.findOne({ source: "mealdb", externalId: meal.idMeal });
    if (exists) continue;

    const tags = meal.strTags ? meal.strTags.split(",").map((t) => t.trim()).filter(Boolean) : [];

    await Dish.create({
      title: meal.strMeal,
      description: meal.strInstructions?.slice(0, 220) ?? "No description",
      imageUrl: meal.strMealThumb,
      cuisine: meal.strArea || "Unknown",
      tags,
      source: "user",
      externalId: meal.idMeal,
      createdBy: null,
      recipe: null,
    });

    inserted++;
  }

  return inserted;
}
