import express from "express";
import cors from "cors";
import path from "path";

import { authRouter } from "./modules/auth/auth.routes.js";
import { coupleRouter } from "./modules/couples/couple.routes.js";
import { dishRouter } from "./modules/dishes/dish.routes.js";
import { swipeRouter } from "./modules/swipes/swipe.routes.js";
import { fileURLToPath } from "url";
import { uploadRouter } from "./modules/uploads/upload.routes.js";
import { recipeRouter } from "./modules/recipes/recipe.routes.js";

export const app = express();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: "2mb" }));

app.use("/uploads", express.static(path.join(__dirname, "..", "uploads")));

app.get("/health", (_req, res) => res.json({ ok: true }));

app.use("/api/auth", authRouter);
app.use("/api/couples", coupleRouter);
app.use("/api/dishes", dishRouter);
app.use("/api/swipes", swipeRouter);
app.use("/api/uploads", uploadRouter);
app.use("/api/recipes", recipeRouter);
