import { Outlet } from "react-router-dom";
import { Box, Container } from "@mui/material";
import { AppBackground } from "../../shared/ui/AppBackround";

export function AppLayout() {
  return (
    <>
      <AppBackground />
      <Box
        sx={{
          minHeight: "100vh",
          py: { xs: 3, md: 6 },
          
        }}
      >
        <Container maxWidth="lg">
          
          <Box sx={{ mt: 3 }}>
            <Outlet />
          </Box>
        </Container>
      </Box>
    </>
  );
}
