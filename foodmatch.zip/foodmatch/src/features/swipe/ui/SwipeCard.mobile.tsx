import { Box, IconButton } from "@mui/material";
import ArrowBackIosNewRoundedIcon from "@mui/icons-material/ArrowBackIosNewRounded";
import CloseRoundedIcon from "@mui/icons-material/CloseRounded";
import LocalFireDepartmentRoundedIcon from "@mui/icons-material/LocalFireDepartmentRounded";
import ReplayRoundedIcon from "@mui/icons-material/ReplayRounded";
import { motion } from "framer-motion";

import { MobileSwipeCardLayout } from "./MobileSwipeCardLayout";

type Dish = {
  imageUrl: string;
  title: string;
  description: string;
  tags: string[];
};

type Props = {
  currentDish: Dish | null | undefined;
  nextDish: Dish | null | undefined;
  isFinished: boolean;

  leftPillText: string;
  rightPillText: string;
  onConnectClick: () => void;

  canSwipe: boolean;
  canGoBack: boolean;

  motionStyle: {
    x: any;
    rotate: any;
    opacity: any;
  };

  backCardStyle: {
    backScale: any;
    backY: any;
    backOpacity: any;
  };

  likeNopeStyle: {
    likeOpacity: any;
    nopeOpacity: any;
    likeY: any;
    nopeY: any;
  };

  onDragEnd: () => void;
  onSwipeLeft: () => void;
  onSwipeRight: () => void;
  onPrevious: () => void;
  onReset: () => void;
};

const BOTTOM_BAR_HEIGHT = 72;
const ACTIONS_BOTTOM_GAP = 2;

const actionsBottom = BOTTOM_BAR_HEIGHT + ACTIONS_BOTTOM_GAP;

export function SwipeCardMobile(props: Props) {
  const {
    currentDish,
    nextDish,
    isFinished,
    leftPillText,
    rightPillText,
    onConnectClick,
    canSwipe,
    canGoBack,
    motionStyle,
    backCardStyle,
    likeNopeStyle,
    onDragEnd,
    onSwipeLeft,
    onSwipeRight,
    onPrevious,
    onReset,
  } = props;

  const { x, rotate, opacity } = motionStyle;
  const { backScale, backY, backOpacity } = backCardStyle;
  const { likeOpacity, nopeOpacity, likeY, nopeY } = likeNopeStyle;

  

  return (
    <Box
      sx={{
        position: "relative",
        width: "100vw",
        height: "100dvh",
        overflow: "hidden",
        bgcolor: "#000",
      }}
    >
      {/* Back card */}
      {!isFinished && nextDish && (
        <motion.div
          style={{
            position: "absolute",
            inset: 0,
            zIndex: 0,
            scale: backScale,
            y: backY,
            opacity: backOpacity,
            pointerEvents: "none",
          }}
        >
          <MobileSwipeCardLayout
            imageUrl={nextDish.imageUrl}
            title={nextDish.title}
            description={nextDish.description}
            tags={nextDish.tags}
            topLeftText={leftPillText}
            topRightText={rightPillText}
            onTopLeftClick={onConnectClick}
          />
        </motion.div>
      )}

      {/* Front card */}
      <motion.div
        style={{
          x,
          rotate,
          opacity,
          touchAction: "pan-y",
          position: "relative",
          zIndex: 1,
          height: "100%",
        }}
        drag={canSwipe ? "x" : false}
        dragConstraints={{ left: 0, right: 0 }}
        dragElastic={0.15}
        onDragEnd={onDragEnd}
      >
        <MobileSwipeCardLayout
          imageUrl={currentDish?.imageUrl}
          title={currentDish?.title}
          description={currentDish?.description}
          tags={currentDish?.tags ?? []}
          topLeftText={leftPillText}
          topRightText={rightPillText}
          onTopLeftClick={onConnectClick}
        />

        {/* NOPE */}
        <motion.div
          style={{
            position: "absolute",
            top: 92,
            left: 218,
            opacity: nopeOpacity,
            y: nopeY,
            pointerEvents: "none",
            zIndex: 6,
          }}
        >
          <Box
            sx={{
              px: 5,
              py: 2,
              borderRadius: 2,
              border: "2px solid #49426C",
              color: "#49426C",
              background: "rgba(255,255,255,0.85)",
              fontWeight: 900,
              letterSpacing: 2,
              fontSize: 28,
              transform: "rotate(-10deg)",
              display: "inline-block",
            }}
          >
            NOPE
          </Box>
        </motion.div>

        {/* LIKE */}
        <motion.div
          style={{
            position: "absolute",
            top: 92,
            right: 218,
            opacity: likeOpacity,
            y: likeY,
            pointerEvents: "none",
            zIndex: 6,
          }}
        >
          <Box
            sx={{
              px: 5,
              py: 2,
              borderRadius: 2,
              border: "2px solid #FF5D1D",
              color: "#FF5D1D",
              background: "rgba(255,255,255,0.85)",
              fontWeight: 900,
              letterSpacing: 2,
              fontSize: 28,
              transform: "rotate(10deg)",
              display: "inline-block",
            }}
          >
            LIKE
          </Box>
        </motion.div>
      </motion.div>

      {/* Action buttons */}
      <Box
        sx={{
          position: "absolute",
          left: 16,
          right: 16,
          bottom: actionsBottom,
          zIndex: 10,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          pointerEvents: "none",
        }}
      >
        <IconButton
          onClick={onPrevious}
          disabled={!canGoBack}
          sx={{
            pointerEvents: "auto",
            width: 44,
            height: 44,
            borderRadius: 999,
            backgroundColor: "rgba(255,255,255,0.12)",
            border: "1px solid rgba(255,255,255,0.18)",
            color: "rgba(255,255,255,0.9)",
            backdropFilter: "blur(8px)",
          }}
        >
          <ArrowBackIosNewRoundedIcon fontSize="small" />
        </IconButton>

        <Box sx={{ pointerEvents: "auto", display: "flex", gap: 2, alignItems: "center", pb: 4 }}>
          <IconButton
            onClick={onSwipeLeft}
            disabled={!canSwipe}
            sx={{
              width: 84,
              height: 84,
              borderRadius: 999,
              backgroundColor: "rgba(255,255,255,0.95)",
              color: "rgba(0,0,0,0.75)",
            }}
          >
            <CloseRoundedIcon />
          </IconButton>

          <IconButton
            onClick={onSwipeRight}
            disabled={!canSwipe}
            sx={{
              width: 84,
              height: 84,
              borderRadius: 999,
              backgroundColor: "rgba(255,90,0,0.95)",
              color: "white",
            }}
          >
            <LocalFireDepartmentRoundedIcon />
          </IconButton>
        </Box>

        <IconButton
          onClick={onReset}
          sx={{
            pointerEvents: "auto",
            width: 44,
            height: 44,
            borderRadius: 999,
            backgroundColor: "rgba(255,255,255,0.12)",
            border: "1px solid rgba(255,255,255,0.18)",
            color: "rgba(255,255,255,0.9)",
            backdropFilter: "blur(8px)",
          }}
        >
          <ReplayRoundedIcon fontSize="small" />
        </IconButton>
      </Box>
    </Box>
  );
}
