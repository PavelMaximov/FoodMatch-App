import type { Response } from "express";
import { z } from "zod";
import type { AuthRequest } from "../../middlewares/auth.middleware.js";
import { Couple } from "./couple.model.js";
import { User } from "../users/user.model.js";
import { Swipe } from "../swipes/swipe.model.js";

function makeInviteCode() {
  // короткий код: 6 символов
  return Math.random().toString(36).slice(2, 8).toUpperCase();
}

export async function createCouple(req: AuthRequest, res: Response) {
  const userId = req.userId!;
  const user = await User.findById(userId);
  if (!user) return res.status(404).json({ message: "User not found" });

  if (user.coupleId) return res.status(400).json({ message: "Already in couple" });

  let inviteCode = makeInviteCode();
  // простая защита от коллизий
  while (await Couple.findOne({ inviteCode })) inviteCode = makeInviteCode();

  const couple = await Couple.create({ inviteCode, members: [user._id] });
  user.coupleId = couple._id;
  await user.save();

  return res.json({ inviteCode });
}

const joinSchema = z.object({ inviteCode: z.string().min(4) });

export async function joinCouple(req: AuthRequest, res: Response) {
  const parsed = joinSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ message: "Invalid input" });

  const userId = req.userId!;
  const user = await User.findById(userId);
  if (!user) return res.status(404).json({ message: "User not found" });
  if (user.coupleId) return res.status(400).json({ message: "Already in couple" });

  const couple = await Couple.findOne({ inviteCode: parsed.data.inviteCode });
  if (!couple) return res.status(404).json({ message: "Invite code not found" });

  if (couple.members.length >= 2) return res.status(400).json({ message: "Couple is full" });

  couple.members.push(user._id);
  await couple.save();

  user.coupleId = couple._id;
  await user.save();

  return res.json({ ok: true });
}

export async function getMyCouple(req: AuthRequest, res: Response) {
  const user = await User.findById(req.userId).select("coupleId");
  if (!user?.coupleId) return res.json({ couple: null });

  const couple = await Couple.findById(user.coupleId)
    .populate({ path: "members", select: "displayName" })
    .lean();

  if (!couple) return res.json({ couple: null });

  const members = (couple.members as any[]).map((m) => ({
    id: String(m._id),
    displayName: String(m.displayName),
  }));

  return res.json({
    couple: {
      inviteCode: couple.inviteCode,
      members,
    },
  });
}

export async function resetCouple(req: AuthRequest, res: Response) {
  const user = await User.findById(req.userId).select("coupleId");
  if (!user?.coupleId) return res.status(400).json({ message: "Not in a session" });

  await Swipe.deleteMany({ coupleId: user.coupleId });
  return res.json({ ok: true });
}

export async function leaveCouple(req: AuthRequest, res: Response) {
  const user = await User.findById(req.userId);
  if (!user?.coupleId) return res.json({ ok: true });

  const coupleId = user.coupleId;
  user.coupleId = null;
  await user.save();

  const couple = await Couple.findById(coupleId);
  if (couple) {
    couple.members = couple.members.filter((m) => String(m) !== String(user._id));
    if (couple.members.length === 0) {
      // никого не осталось — удаляем пару и свайпы
      await Swipe.deleteMany({ coupleId });
      await couple.deleteOne();
    } else {
      await couple.save();
    }
  }

  return res.json({ ok: true });
}
