export function debounce<T extends (...args: unknown[]) => void>(fn: T, delayMs: number) {
  let t: number | undefined;

  return (...args: Parameters<T>) => {
    if (t) window.clearTimeout(t);
    t = window.setTimeout(() => fn(...args), delayMs);
  };
}
