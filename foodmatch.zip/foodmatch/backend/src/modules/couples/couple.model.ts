import { Schema, model, type InferSchemaType } from "mongoose";

const coupleSchema = new Schema(
  {
    inviteCode: { type: String, required: true, unique: true, index: true },
    members: [{ type: Schema.Types.ObjectId, ref: "User", required: true }],
  },
  { timestamps: true }
);

export type CoupleDoc = InferSchemaType<typeof coupleSchema>;
export const Couple = model("Couple", coupleSchema);
