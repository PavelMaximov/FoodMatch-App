import {
  Dialog,
  DialogContent,
  DialogTitle,
  Typography,
  Button,
  TextField,
  Box,
  Stack,
  Divider,
} from "@mui/material";
import { useEffect, useMemo, useState } from "react";
import ContentCopyRoundedIcon from "@mui/icons-material/ContentCopyRounded";
import AddRoundedIcon from "@mui/icons-material/AddRounded";

import { useAuth } from "../../auth/model/useAuth";
import { useCoupleSession } from "../model/useCoupleSession";
import { createCoupleApi, joinCoupleApi, resetCoupleApi, leaveCoupleApi } from "../api/couple.api";

type Props = {
  open: boolean;
  onClose: () => void;
};

export function ConnectSessionDialog({ open, onClose }: Props) {
  const { user } = useAuth();
  const { session, refresh } = useCoupleSession();

  const myName = user?.displayName ?? "You";

  const inviteCode = session.status === "active" ? session.inviteCode : null;
  const members = session.status === "active" ? session.members : [];
  const membersCount = members.length;

  const partnerName = useMemo(() => {
    if (session.status !== "active") return null;
    const partner = members.find((m) => m.displayName !== myName);
    return partner?.displayName ?? null;
  }, [session.status, members, myName]);

  const [inviteInput, setInviteInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (open) {
      refresh();
      setInviteInput("");
      setCopied(false);
    }
  }, [open, refresh]);

  async function copyCode() {
    if (!inviteCode) return;

    try {
      await navigator.clipboard.writeText(inviteCode);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = inviteCode;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
    }

    setCopied(true);
    window.setTimeout(() => setCopied(false), 900);
  }

  async function handleCreate() {
    setLoading(true);
    try {
      await createCoupleApi();
      window.dispatchEvent(new Event("foodmatch:sessionChanged"));
      await refresh();
    } finally {
      setLoading(false);
    }
  }

  async function handleJoin() {
    setLoading(true);
    try {
      await joinCoupleApi(inviteInput.trim().toUpperCase());
      window.dispatchEvent(new Event("foodmatch:sessionChanged"));
      await refresh();
    } finally {
      setLoading(false);
    }
  }

  async function handleReset() {
    setLoading(true);
    try {
      await resetCoupleApi();
      window.dispatchEvent(new Event("foodmatch:sessionChanged"));
      await refresh();
    } finally {
      setLoading(false);
    }
  }

  async function handleLeave() {
    setLoading(true);
    try {
      await leaveCoupleApi();
      window.dispatchEvent(new Event("foodmatch:sessionChanged"));
      await refresh();
    } finally {
      setLoading(false);
    }
  }

  // ====== стили кнопок ======
  const primaryBtnSx = {
    py: 1.35,
    borderRadius: 999,
    color: "white",
    background: "linear-gradient(90deg,#FB4B11,#FF5D1D)",
    boxShadow: "none",
    fontWeight: 900,
    "&:hover": { background: "linear-gradient(90deg,#FB4B11,#FF5D1D)", opacity: 0.95, boxShadow: "none" },
  } as const;

  const secondaryBtnSx = {
    py: 1.25,
    borderRadius: 999,
    fontWeight: 900,
    borderColor: "rgba(73,66,108,0.55)",
    color: "#49426C",
    "&:hover": { borderColor: "rgba(73,66,108,0.75)" },
  } as const;

  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="sm">
      <DialogTitle sx={{ fontWeight: 900, fontSize: 24 }}>Connect session</DialogTitle>

      <DialogContent sx={{ pb: 3 }}>
        <Stack spacing={2} sx={{ pt: 0.5 }}>
          {/* Who */}
          <Box>
            <Typography sx={{ fontWeight: 900 }}>
              You: <span style={{ fontWeight: 800 }}>{myName}</span>
            </Typography>

            <Typography sx={{ mt: 0.6, color: "rgba(16,17,19,0.55)" }}>
              Partner: {inviteCode ? (partnerName ? partnerName : "Waiting for partner...") : "—"}
            </Typography>
          </Box>

          {/* If session active: show code + actions */}
          {inviteCode && (
            <Box
              sx={{
                borderRadius: 4,
                border: "1px solid rgba(16,17,19,0.10)",
                background: "rgba(255,255,255,0.65)",
                p: 2,
              }}
            >
              <Typography sx={{ fontWeight: 900, mb: 0.5 }}>Invite code</Typography>

              <Box sx={{ display: "flex", alignItems: "center", gap: 1.2 }}>
                <Typography sx={{ fontSize: 26, letterSpacing: 4, fontWeight: 900, color: "#101113" }}>
                  {inviteCode}
                </Typography>

                <Button
                  onClick={copyCode}
                  variant="outlined"
                  size="small"
                  startIcon={<ContentCopyRoundedIcon />}
                  sx={{
                    borderRadius: 999,
                    borderColor: "rgba(73,66,108,0.35)",
                    color: "#49426C",
                    fontWeight: 900,
                    "&:hover": { borderColor: "rgba(73,66,108,0.55)" },
                    whiteSpace: "nowrap",
                  }}
                >
                  {copied ? "Copied" : "Copy"}
                </Button>
              </Box>

              <Typography sx={{ mt: 0.8, color: "rgba(16,17,19,0.55)" }}>
                Members: {membersCount} / 2
              </Typography>

              <Box sx={{ display: "flex", gap: 1.5, mt: 2 }}>
                <Button fullWidth variant="outlined" onClick={handleReset} disabled={loading} sx={secondaryBtnSx}>
                  Reset matches
                </Button>

                <Button fullWidth onClick={handleLeave} disabled={loading} sx={primaryBtnSx}>
                  Leave
                </Button>
              </Box>
            </Box>
          )}

          {/* If no session: create */}
          {!inviteCode && (
            <Button
              onClick={handleCreate}
              disabled={loading}
              startIcon={<AddRoundedIcon />}
              sx={primaryBtnSx}
            >
              Create session
            </Button>
          )}

          <Divider sx={{ borderColor: "rgba(16,17,19,0.12)" }} />

          {/* Join */}
          <Box>
            <Typography sx={{ fontWeight: 900, mb: 1 }}>Join with code</Typography>

            <Box sx={{ display: "flex", gap: 1.2, alignItems: "center" }}>
              <TextField
                value={inviteInput}
                onChange={(e) => setInviteInput(e.target.value)}
                placeholder="Enter invite code"
                fullWidth
                InputProps={{
                  sx: {
                    borderRadius: 4,
                    background: "rgba(0,0,0,0.04)",
                  },
                }}
              />

              <Button
                variant="outlined"
                onClick={handleJoin}
                disabled={loading || inviteInput.trim().length < 4}
                sx={{
                  ...secondaryBtnSx,
                  px: 3,
                  py: 1.35,
                }}
              >
                Join
              </Button>
            </Box>
          </Box>

          <Button
            variant="text"
            onClick={onClose}
            sx={{ fontWeight: 900, color: "#49426C", "&:hover": { background: "transparent", opacity: 0.85 } }}
          >
            Close
          </Button>
        </Stack>
      </DialogContent>
    </Dialog>
  );
}
