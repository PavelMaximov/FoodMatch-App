import { Schema, model, type InferSchemaType } from "mongoose";

const swipeSchema = new Schema(
  {
    userId: { type: Schema.Types.ObjectId, ref: "User", required: true, index: true },
    coupleId: { type: Schema.Types.ObjectId, ref: "Couple", required: true, index: true },
    dishId: { type: Schema.Types.ObjectId, ref: "Dish", required: true, index: true },
    action: { type: String, enum: ["like", "dislike"], required: true },
  },
  { timestamps: true }
);

// один пользователь может свайпнуть одно блюдо один раз (перезаписываем)
swipeSchema.index({ userId: 1, dishId: 1 }, { unique: true });

export type SwipeDoc = InferSchemaType<typeof swipeSchema>;
export const Swipe = model("Swipe", swipeSchema);
