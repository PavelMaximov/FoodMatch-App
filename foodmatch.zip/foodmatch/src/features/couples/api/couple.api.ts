import { api } from "../../../shared/api/http";

export type CreateCoupleResponse = { inviteCode: string };
export type JoinCoupleResponse = { ok: true };
export type MyCoupleResponse = {
  couple: {
    inviteCode: string;
    members: { id: string; displayName: string }[];
  } | null;
};

export function createCoupleApi() {
  return api<CreateCoupleResponse>("/api/couples/create", { method: "POST", auth: true });
}

export function joinCoupleApi(inviteCode: string) {
  return api<JoinCoupleResponse>("/api/couples/join", { method: "POST", body: { inviteCode }, auth: true });
}

export function myCoupleApi() {
  return api<MyCoupleResponse>("/api/couples/me", { method: "GET", auth: true });
}

export function resetCoupleApi() {
  return api<{ ok: true }>("/api/couples/reset", { method: "POST", auth: true });
}

export function leaveCoupleApi() {
  return api<{ ok: true }>("/api/couples/leave", { method: "POST", auth: true });
}