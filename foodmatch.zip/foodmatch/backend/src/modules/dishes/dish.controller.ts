import type { Request, Response } from "express";
import { isValidObjectId } from "mongoose";
import { Dish } from "./dish.model.js";

// GET /api/dishes
export async function listDishes(req: Request, res: Response) {
  const dishes = await Dish.find().sort({ createdAt: -1 });
  res.json({ dishes });
}

// POST /api/dishes  (admin)
export async function createDish(req: Request, res: Response) {
  try {
    const created = await Dish.create(req.body);
    res.status(201).json({ dish: created });
  } catch (e: any) {
    console.error("createDish error:", e);
    res.status(400).json({
      message: e?.message ?? "Failed to create dish",
      details: e?.errors ?? null,
    });
  }
}

// GET /api/dishes/:id
export async function getDishById(req: Request, res: Response) {
  const { id } = req.params;
  if (!isValidObjectId(id)) return res.status(400).json({ message: "Invalid id" });

  const dish = await Dish.findById(id);
  if (!dish) return res.status(404).json({ message: "Dish not found" });

  res.json({ dish });
}

// PATCH /api/dishes/:id (admin)
export async function updateDishById(req: Request, res: Response) {
  try {
    const { id } = req.params;
    if (!isValidObjectId(id)) return res.status(400).json({ message: "Invalid id" });

    const updated = await Dish.findByIdAndUpdate(id, req.body, {
      new: true,
      runValidators: true,
    });

    if (!updated) return res.status(404).json({ message: "Dish not found" });
    res.json({ dish: updated });
  } catch (e: any) {
    console.error("updateDishById error:", e);
    res.status(400).json({ message: e?.message ?? "Failed to update dish" });
  }
}


// DELETE /api/dishes/:id (admin)
export async function deleteDishById(req: Request, res: Response) {
  const { id } = req.params;
  if (!isValidObjectId(id)) return res.status(400).json({ message: "Invalid id" });

  const deleted = await Dish.findByIdAndDelete(id);
  if (!deleted) return res.status(404).json({ message: "Dish not found" });

  res.json({ ok: true });
}
