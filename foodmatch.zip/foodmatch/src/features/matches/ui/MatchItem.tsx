import { Box, Chip, Typography } from "@mui/material";

type Props = {
  tag: string;
  title: string;
  onClick?: () => void;
  selected?: boolean;
};

export function MatchItem({ tag, title, onClick, selected }: Props) {
 return (
    <Box
      onClick={onClick}
      role={onClick ? "button" : undefined}
      tabIndex={onClick ? 0 : undefined}
      onKeyDown={(e) => {
        if (!onClick) return;
        if (e.key === "Enter" || e.key === " ") onClick();
      }}
      sx={{
        display: "flex",
        alignItems: "center",
        gap: 1.2,
        px: 1.2,
        py: 0.9,
        borderRadius: 999,
        border: selected
          ? "1px solid rgba(251,75,17,0.65)"
          : "1px solid rgba(16,17,19,0.12)",
        background: selected ? "rgba(251,75,17,0.20)" : "rgba(255,255,255,0.70)",
        cursor: onClick ? "pointer" : "default",
        userSelect: "none",
        "&:hover": onClick 
        ? { background: selected ? "rgba(251,75,17,0.24)" : "rgba(255,255,255,0.85)" } 
        : undefined,
      }}
    >
      <Chip
        label={tag}
        size="small"
        sx={{
          height: 26,
          borderRadius: 999,
          background: selected ? "rgba(251, 76, 17, 0.37)" : "rgba(0,0,0,0.06)",
          fontWeight: 800,
          "& .MuiChip-label": { px: 1.4 },
        }}
      />

      <Typography
        sx={{
          fontWeight: 900,
          minWidth: 0,
          overflow: "hidden",
          textOverflow: "ellipsis",
          whiteSpace: "nowrap",
          flex: 1,
        }}
        title={title}
      >
        {title}
      </Typography>
    </Box>
  );
}
