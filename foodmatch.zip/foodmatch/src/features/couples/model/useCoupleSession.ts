import { useCallback, useEffect, useState } from "react";
import { myCoupleApi } from "../api/couple.api";

export type CoupleMember = { id: string; displayName: string };

export type CoupleSessionState =
  | { status: "none" }
  | { status: "active"; inviteCode: string; members: CoupleMember[] };

export function useCoupleSession() {
  const [session, setSession] = useState<CoupleSessionState>({ status: "none" });
  const [loading, setLoading] = useState(false);

  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const res = await myCoupleApi();
      if (!res.couple) {
        setSession({ status: "none" });
        return;
      }
      setSession({ status: "active", inviteCode: res.couple.inviteCode, members: res.couple.members });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  useEffect(() => {
    const handler = () => refresh();
    window.addEventListener("foodmatch:sessionChanged", handler);
    return () => window.removeEventListener("foodmatch:sessionChanged", handler);
  }, [refresh]);

  return { session, loading, refresh };
}
