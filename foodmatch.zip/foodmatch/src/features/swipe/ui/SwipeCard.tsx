import {
  Box,
  useMediaQuery,
} from "@mui/material";
import { useTheme } from "@mui/material/styles";
import { motion, useMotionValue, useTransform, animate } from "framer-motion";
import { useMemo, useState } from "react";

import type { SwipeDeck } from "../ui/model/useSwipeDeck";
import { useCoupleSession } from "../../couples/model/useCoupleSession";
import { ConnectSessionDialog } from "../../couples/ui/ConnectSessionDialog";

import { SwipeCardDesktop } from "./SwipeCard.desktop.tsx";
import { SwipeCardMobile } from "./SwipeCard.mobile.tsx";

type Props = {
  swipe: SwipeDeck;
  connectedLabel?: string;
  onConnectClick?: () => void;
};

const THRESHOLD = 20;

export function SwipeCard({ swipe, connectedLabel, onConnectClick }: Props) {
  const {
    currentDish,
    nextDish,
    isFinished,
    canGoBack,
    canSwipe,
    swipe: doSwipe,
    previous,
    reset,
  } = swipe;

  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("md"));

  const { session, loading } = useCoupleSession();
  const [connectOpen, setConnectOpen] = useState(false);

  // Текст статуса сессии 
  const sessionText = useMemo(() => {
    if (loading) return "Session...";
    if (!session) return "Not connected";

    const status = session.status ?? "none";
    if (status === "none") return "Not connected";

    const count = (session as { members?: unknown[] }).members?.length ?? 0;
    if (count >= 2) return "Connected 2/2";
    return "Waiting 1/2";
  }, [session, loading]);

  // --- Framer Motion ---
  const x = useMotionValue(0);
  const rotate = useTransform(x, [-200, 0, 200], [-8, 0, 8]);
  const opacity = useTransform(x, [-220, 0, 220], [0.85, 1, 0.85]);

  const backScale = useTransform(x, [-160, 0, 160], [1.0, 0.975, 1.0]);
  const backY = useTransform(x, [-160, 0, 160], [0, 10, 0]);
  const backOpacity = useTransform(x, [-160, 0, 160], [1, 0, 1]);

  const likeOpacity = useTransform(x, [0, 40, 140], [0, 0.25, 1]);
  const nopeOpacity = useTransform(x, [-140, -40, 0], [1, 0.25, 0]);
  const likeY = useTransform(x, [0, 140], [8, 0]);
  const nopeY = useTransform(x, [-140, 0], [0, 8]);

  function snapBack() {
    animate(x, 0, { type: "spring", stiffness: 500, damping: 35 });
  }

  function flyOut(direction: "left" | "right") {
    const toX = direction === "right" ? 480 : -480;

    animate(x, toX, {
      type: "spring",
      stiffness: 280,
      damping: 28,
      onComplete: () => {
        x.set(0);
        doSwipe(direction === "right" ? "like" : "dislike");
      },
    });
  }

  function handleDragEnd() {
    const offset = x.get();
    if (offset > THRESHOLD) return flyOut("right");
    if (offset < -THRESHOLD) return flyOut("left");
    snapBack();
  }


  const handleConnectClick = () => {
    if (onConnectClick) return onConnectClick();
    setConnectOpen(true);
  };

  // Чтобы reset не оставлял карточку сдвинутой
  const handleReset = () => {
    reset();
    x.set(0);
  };

  return (
    <Box sx={{ position: "relative" }}>
      <ConnectSessionDialog open={connectOpen} onClose={() => setConnectOpen(false)} />

      {isMobile ? (
        <SwipeCardMobile
          // data
          currentDish={currentDish}
          nextDish={nextDish}
          isFinished={isFinished}
          // session pills
          leftPillText="Connect session"
          rightPillText={connectedLabel ?? sessionText}
          onConnectClick={handleConnectClick}
          // motion / swipe
          canSwipe={canSwipe}
          canGoBack={canGoBack}
          motionStyle={{ x, rotate, opacity }}
          backCardStyle={{ backScale, backY, backOpacity }}
          likeNopeStyle={{ likeOpacity, nopeOpacity, likeY, nopeY }}
          onDragEnd={handleDragEnd}
          onSwipeLeft={() => flyOut("left")}
          onSwipeRight={() => flyOut("right")}
          onPrevious={previous}
          onReset={handleReset}
        />
      ) : (
        <SwipeCardDesktop
          // data
          currentDish={currentDish}
          nextDish={nextDish}
          isFinished={isFinished}
          // header
          connectedLabel={connectedLabel}
          onConnectClick={handleConnectClick}
          // motion / swipe
          canSwipe={canSwipe}
          canGoBack={canGoBack}
          motionStyle={{ x, rotate, opacity }}
          backCardStyle={{ backScale, backY, backOpacity }}
          likeNopeStyle={{ likeOpacity, nopeOpacity, likeY, nopeY }}
          onDragEnd={handleDragEnd}
          onSwipeLeft={() => flyOut("left")}
          onSwipeRight={() => flyOut("right")}
          onPrevious={previous}
          onReset={handleReset}
        />
      )}
    </Box>
  );
}
