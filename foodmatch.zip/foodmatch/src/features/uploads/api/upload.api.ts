const API_URL = import.meta.env.VITE_API_URL ?? "http://localhost:4000";
const ADMIN_TOKEN = import.meta.env.VITE_ADMIN_TOKEN ?? "";

export async function uploadImage(file: File): Promise<string> {
  const form = new FormData();
  form.append("file", file);

  const res = await fetch(`${API_URL}/api/uploads`, {
    method: "POST",
    headers: {
      "x-admin-token": ADMIN_TOKEN, 
    },
    body: form,
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data?.message ?? "Upload failed");

  return data.url ?? data.imageUrl ?? data.path;
}
