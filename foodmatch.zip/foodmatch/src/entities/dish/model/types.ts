export type Dish = {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  tags: string[]; // например: ["USA", "Nourishing"]
  createdBy?: string; // если добавлено пользователем (позже)
};
