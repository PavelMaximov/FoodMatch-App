import { Box, Button, Typography } from "@mui/material";
import { motion } from "framer-motion";
import { useEffect, useState } from "react";

type Props = {
    open: boolean;
    dishTitle: string;
    dishImageUrl: string;
    otherUserName?: string;
    onContinue: () => void;
    onGoToResults: () => void;
};

type ConfettiPiece = {
    id: string;
    x: number;
    y: number;
    rotate: number;
    driftX: number;
    fallY: number;
    scale: number;
    duration: number;
    delay: number;
};

function ConfettiBurst({ active }: { active: boolean }) {
    const [pieces, setPieces] = useState<ConfettiPiece[]>([]);

    useEffect(() => {
        if (!active) {
            setPieces([]);
            return;
        }

        const arr: ConfettiPiece[] = [];
        for (let i = 0; i < 26; i++) {
            arr.push({
                id: `c${i}`,
                x: 50 + (Math.random() * 18 - 9),
                y: 52 + (Math.random() * 8 - 4),
                rotate: Math.random() * 160 - 80,
                driftX: Math.random() * 50 - 25,
                fallY: 60 + Math.random() * 35,
                scale: 0.8 + Math.random() * 0.8,
                duration: 1.8 + Math.random() * 1.4,
                delay: Math.random() * 0.25,
            });
        }
        setPieces(arr);
    }, [active]);

    if (!active) return null;

    return (
        <Box sx={{ position: "absolute", inset: 0, zIndex: 4, pointerEvents: "none" }}>
            {pieces.map((p, idx) => (
                <motion.div
                    key={p.id}
                    initial={{
                        opacity: 0,
                        left: `${p.x}%`,
                        top: `${p.y}%`,
                        x: 0,
                        y: 0,
                        rotate: p.rotate,
                        scale: p.scale,
                    }}
                    animate={{
                        opacity: [0, 1, 1, 0],
                        x: [0, p.driftX],
                        y: [0, p.fallY],
                        rotate: [p.rotate, p.rotate + (idx % 2 === 0 ? 220 : -220)],
                    }}
                    transition={{
                        duration: p.duration,
                        delay: p.delay,
                        ease: "easeOut",
                    }}
                    style={{
                        position: "absolute",
                        width: 10,
                        height: 14,
                        borderRadius: 3,
                        background:
                            idx % 3 === 0
                                ? "rgba(255,93,29,0.95)"
                                : idx % 3 === 1
                                    ? "rgba(255,255,255,0.90)"
                                    : "rgba(73,66,108,0.95)",
                        boxShadow: "0 8px 22px rgba(0,0,0,0.35)",
                    }}
                />
            ))}
        </Box>
    );
}



export function MatchScreen({
    open,
    dishTitle,
    dishImageUrl,
    otherUserName = "Partner",
    onContinue,
    onGoToResults,
}: Props) {
    if (!open) return null;

    return (
        <Box
            sx={{
                position: "fixed",
                inset: 0,
                zIndex: 2000,
                display: { xs: "block", md: "none" },
                overflow: "hidden",
            }}
        >
            {/* background */}
            <Box
                sx={{
                    position: "absolute",
                    inset: 0,
                    background:
                        "radial-gradient(900px 700px at 25% 15%, rgba(255,93,29,0.28) 0%, rgba(0,0,0,0) 55%), radial-gradient(900px 700px at 85% 20%, rgba(73,66,108,0.30) 0%, rgba(0,0,0,0) 60%), linear-gradient(180deg, rgba(16,16,20,0.92) 0%, rgba(12,12,16,0.96) 100%)",
                }}
            />

            {/* confetti */}
            <ConfettiBurst active={open} />

            {/* content */}
            <Box
                sx={{
                    position: "relative",
                    height: "100dvh",
                    px: 2.2,
                    pt: 6,
                    pb: "calc(18px + env(safe-area-inset-bottom))",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                }}
            >
                <Typography
                    sx={{
                        fontFamily: `"Pacifico", cursive`,
                        fontSize: 48,
                        lineHeight: 1.7,
                        color: "white",
                        textAlign: "center",
                        mt: 1,
                    }}
                >
                    Congratulations
                </Typography>

                <Typography
                    sx={{
                        mt: 0.5,
                        fontSize: 38,
                        lineHeight: 1.1,
                        fontWeight: 800,
                        color: "white",
                        textAlign: "center",
                    }}
                >
                    You have a{" "}
                    <span style={{ fontFamily: `"Pacifico", cursive` }}>Match!</span>
                </Typography>

                {/* floating image + icons */}
                <Box sx={{ position: "relative", mt: 6, width: "100%", display: "grid", placeItems: "center" }}>
                    {/* glow */}
                    <Box
                        sx={{
                            position: "absolute",
                            width: 460,
                            height: 460,
                            borderRadius: 999,
                            background: "radial-gradient(circle, rgba(146, 29, 255, 0.28) 0%, rgba(0,0,0,0) 65%)",
                        }}
                    />

                   

                    {/* floating image */}
                    <motion.div
                        animate={{ y: [0, -10, 0], scale: [1, 1.02, 1] }}
                        transition={{ duration: 2.8, repeat: Infinity, ease: "easeInOut" }}
                        style={{ position: "relative", zIndex: 2 }}
                    >
                        <Box
                            component="img"
                            src={dishImageUrl}
                            alt={dishTitle}
                            sx={{
                                width: 290,
                                height: 290,
                                borderRadius: 3,
                                objectFit: "cover",
                                boxShadow: "0 18px 50px rgba(0,0,0,0.55)",
                            }}
                        />
                    </motion.div>
                </Box>

                {/* bottom card */}
                <Box
                    sx={{
                        mt: "auto",
                        width: "100%",
                        borderRadius: 3,
                        bgcolor: "rgba(255,255,255,0.10)",
                        backdropFilter: "blur(10px)",
                        boxShadow: "0 18px 60px rgba(0,0,0,0.35)",
                        px: 5.2,
                        py: 5.4,

                    }}
                >
                    <Typography
                        sx={{
                            fontSize: 38,
                            fontWeight: 900,
                            color: "white",
                            textAlign: "center",
                            mb: 0.2,
                        }}
                    >
                        You and {otherUserName}
                    </Typography>

                    <Typography sx={{ textAlign: "center", color: "rgba(255,255,255,0.78)", mb: 2.6, fontSize: 20, }}>
                        have chosen the same dish.
                    </Typography>

                    <Typography sx={{ textAlign: "center", color: "rgba(255,255,255,0.68)", mb: 1.6 }}>
                        Now you have a choice
                    </Typography>

                    <Button
                        fullWidth
                        onClick={onContinue}
                        variant="contained"
                        sx={{
                            borderRadius: 999,
                            py: 2,
                            fontSize: 20,
                            fontWeight: 900,
                            textTransform: "none",
                            bgcolor: "#FF5D1D",
                            "&:hover": { bgcolor: "#FF5D1D", opacity: 0.95 },
                        }}
                    >
                        Continue browsing
                    </Button>

                    <Button
                        fullWidth
                        onClick={onGoToResults}
                        variant="contained"
                        sx={{
                            mt: 2,
                            borderRadius: 999,
                            py: 2,
                            fontSize: 20,
                            fontWeight: 900,
                            textTransform: "none",
                            bgcolor: "white",
                            color: "#111",
                            "&:hover": { bgcolor: "white", opacity: 0.95 },
                        }}
                    >
                        Go to match results
                    </Button>
                </Box>
            </Box>
        </Box>
    );
}
