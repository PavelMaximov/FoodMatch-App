import { Router } from "express";
import { requireAuth } from "../../middlewares/auth.middleware.js";
import { createCouple, joinCouple, getMyCouple, resetCouple, leaveCouple } from "./couple.controller.js";

export const coupleRouter = Router();

coupleRouter.post("/create", requireAuth, createCouple);
coupleRouter.post("/join", requireAuth, joinCouple);
coupleRouter.get("/me", requireAuth, getMyCouple);
coupleRouter.post("/reset", requireAuth, resetCouple);
coupleRouter.post("/leave", requireAuth, leaveCouple);