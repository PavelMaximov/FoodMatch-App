import {
    Box,
    Card,
    CardContent,
    Chip,
    Typography,
    Checkbox,
    Alert,
    
} from "@mui/material";
import {  useMemo, useState } from "react";
import { useNavigate, } from "react-router-dom";
import ArrowBackIosNewRoundedIcon from "@mui/icons-material/ArrowBackIosNewRounded";
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import RestaurantIcon from '@mui/icons-material/Restaurant';

import { type RecipeResponse } from "../../features/recipes/api/recipes.api";

type Props = {
  data: RecipeResponse;
};

export function RecipeCard({ data }: Props) {
  const nav = useNavigate();

  const dish = data.dish;
  const recipe = data.recipe;

  const [checked, setChecked] = useState<Record<number, boolean>>({});

  const tags = useMemo(() => {
    const base = dish.cuisine ? [dish.cuisine] : [];
    return [...base, ...(dish.tags ?? [])].slice(0, 3);
  }, [dish.cuisine, dish.tags]);


    return (
        <Card
            sx={{

                overflow: "hidden",
                // maxWidth: 760,
                background: "rgba(255,255,255,0.96)",
                boxShadow: "0 18px 60px rgba(0,0,0,0.35)",
            }}
        >
            <CardContent sx={{ p: 4 }}>
                {/* Back (как pill-кнопка) */}
                <Box
                    onClick={() => nav("/swipe")}
                    sx={{
                        display: "inline-flex",
                        alignItems: "center",
                        gap: 1,
                        px: 2.2,
                        py: 1.1,
                        borderRadius: 999,
                        border: "1px solid rgba(115,118,121,0.85)",
                        color: "#737679",
                        cursor: "pointer",
                        userSelect: "none",
                        "&:hover": { background: "rgba(0,0,0,0.03)" },
                    }}
                >
                    <ArrowBackIosNewRoundedIcon sx={{ fontSize: 16 }} />
                    <Typography sx={{ fontWeight: 900 }}>Back</Typography>
                </Box>

                {/* Header: image + content */}
                <Box
                    sx={{
                        mt: 3,
                        display: "grid",
                        gridTemplateColumns: "170px 1fr",
                        gap: 3,
                        alignItems: "start",
                    }}
                >
                    <Box
                        component="img"
                        src={dish.imageUrl}
                        alt={dish.title}
                        sx={{
                            width: 170,
                            height: 170,
                            borderRadius: 3,
                            objectFit: "cover",
                            border: "1px solid rgba(16,17,19,0.12)",
                        }}
                    />

                    <Box sx={{ minWidth: 0 }}>
                        <Typography sx={{ fontSize: 34, fontWeight: 900, lineHeight: 1.1 }}>
                            {dish.title}
                        </Typography>

                        <Typography sx={{ color: "rgba(16,17,19,0.72)", mt: 1, fontSize: 13 }}>
                            {dish.description}
                        </Typography>

                        <Box sx={{ display: "flex", flexWrap: "wrap", gap: 1, mt: 2 }}>
                            {tags.map((t) => (
                                <Chip
                                    key={t}
                                    label={t}
                                    variant="outlined"
                                    size="small"
                                    sx={{
                                        height: 30,
                                        borderRadius: 999,
                                        borderColor: "rgba(115,118,121,0.75)",
                                        "& .MuiChip-label": { px: 1.8, fontWeight: 800, color: "#4B4D57" },
                                    }}
                                />
                            ))}
                        </Box>
                    </Box>
                </Box>

                {/* Meta строка как на макете */}
                <Box sx={{ display: "flex", gap: 2.2, mt: 3, color: "rgba(16,17,19,0.65)" }}>
                    <Typography sx={{ fontWeight: 700, fontSize: 13 }}>
                       <RestaurantIcon sx={{ fontSize: 13, verticalAlign: "middle", mr: 0.5 }} /> Serves: 2 people
                    </Typography>
                    <Typography sx={{ fontWeight: 700, fontSize: 13 }}>
                         <AccessTimeIcon sx={{ fontSize: 15, verticalAlign: "middle", mr: 0.5 }} /> Total Time: 22 mins
                    </Typography>
                </Box>

                {/* Контейнер рецепта со СВОИМ скроллом */}
                <Box
                    sx={{
                        mt: 1.5,
                        height: 520,
                        overflowY: "auto",
                        pr: 1.5,
                        borderRadius: 3,
                        background: "rgba(0,0,0,0.02)",
                        border: "1px solid rgba(16,17,19,0.06)",

                        // чуть красивее скроллбар (chrome/edge)
                        "&::-webkit-scrollbar": { width: 10 },
                        "&::-webkit-scrollbar-thumb": {
                            background: "rgba(16,17,19,0.25)",
                            borderRadius: 999,
                            
                        },
                        "&::-webkit-scrollbar-track": { background: "transparent" },
                    }}
                >
                    <Box sx={{ p: 3 }}>
                        {!recipe ? (
                            <Alert severity="info" sx={{ borderRadius: 3 }}>
                                Для этого блюда пока нет рецепта. (Следующий шаг: добавим ввод рецепта для user-блюд)
                            </Alert>
                        ) : (
                            <>
                                {/* Ingredients */}
                                <Typography sx={{ fontSize: 40, fontWeight: 500, mb: 1 }}>
                                    Ingredients
                                </Typography>

                                <Box sx={{ display: "flex", flexDirection: "column", gap: 0.1 }}>
                                    {recipe.ingredients.map((item, idx) => (
                                        <Box key={idx} sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                                            <Checkbox
                                                checked={Boolean(checked[idx])}
                                                onChange={(e) =>
                                                    setChecked((p) => ({ ...p, [idx]: e.target.checked }))
                                                }
                                                sx={{
                                                    mt: -0.4,
                                                    color: "rgba(16,17,19,0.45)",
                                                    "&.Mui-checked": { color: "rgba(255, 93, 29, 0.8)" },
                                                }}
                                            />
                                            <Typography sx={{ color: "rgba(16,17,19,0.78)", fontSize: 13 }}>
                                                {item}
                                            </Typography>
                                        </Box>
                                    ))}
                                </Box>

                                <Box sx={{ height: 28 }} />

                                {/* Instructions */}
                                <Typography sx={{ fontSize: 40, fontWeight: 500, mb: 1 }}>
                                    Instructions
                                </Typography>

                                <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
                                    {recipe.steps.map((s, i) => (
                                        <Box key={i} sx={{ display: "flex",  gap: 1.5 }}>
                                            <Box
                                                sx={{
                                                    width: 26,
                                                    height: 26,
                                                    borderRadius: "50%",
                                                    border: "2px solid rgba(16,17,19,0.35)",
                                                    display: "grid",
                                                    placeItems: "center",
                                                    fontWeight: 900,
                                                    flex: "0 0 auto",
                                                    mt: 0.2,
                                                    fontSize: 12,
                                                }}
                                            >
                                                {i + 1}
                                            </Box>

                                            <Box>
                                                <Typography sx={{ fontWeight: 900, fontSize: 13 }}>
                                                    {s.title}
                                                </Typography>
                                                <Typography sx={{ color: "rgba(16,17,19,0.70)", mt: 0.4, fontSize: 13 }}>
                                                    {s.text}
                                                </Typography>
                                            </Box>
                                        </Box>
                                    ))}
                                </Box>
                            </>
                        )}
                    </Box>
                </Box>
            </CardContent>
        </Card>
    );
}
