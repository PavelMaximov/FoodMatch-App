import { Box, Typography } from "@mui/material";
import CheckRoundedIcon from "@mui/icons-material/CheckRounded";

type Props = {
  onClose?: () => void;
};

export function AddDishSuccess({ onClose }: Props) {
  return (
    <Box
      onClick={onClose}
      role="button"
      tabIndex={0}
      sx={{
        position: "absolute",
        inset: 0,
        borderRadius: 5,
        background: "white",
        display: "grid",
        placeItems: "center",
        textAlign: "center",
        p: 3,
        cursor: onClose ? "pointer" : "default",
      }}
    >
      <Box>
        <Box
          sx={{
            width: 72,
            height: 72,
            borderRadius: "50%",
            background: "#16C60C",
            display: "grid",
            placeItems: "center",
            mx: "auto",
            mb: 2,
          }}
        >
          <CheckRoundedIcon sx={{ color: "white", fontSize: 44 }} />
        </Box>

        <Typography sx={{ fontSize: 34, lineHeight: 1.1, fontWeight: 500 }}>
          You added your dish
        </Typography>

        <Typography
          sx={{
            mt: 1,
            fontSize: 34,
            lineHeight: 1.1,
            fontFamily: `"Pacifico", cursive`,
          }}
        >
          successfully!
        </Typography>
      </Box>
    </Box>
  );
}
