import { api } from "../../../shared/api/http";

export type DishDTO = {
  _id: string;
  title: string;
  description: string;
  imageUrl: string;
  cuisine: string;
  tags: string[];
  source: "mealdb" | "user";
  createdBy?: string | null;
};

export type ListDishesResponse = { dishes: DishDTO[] };
export type CreateDishResponse = { dish: DishDTO };

export function listDishesApi(params?: { cuisine?: string }) {
  const qs = params?.cuisine ? `?cuisine=${encodeURIComponent(params.cuisine)}` : "";
  return api<ListDishesResponse>(`/api/dishes${qs}`, { method: "GET", auth: true });
}

export function createDishApi(payload: {
  title: string;
  description: string;
  imageUrl: string;
  cuisine: string;
  tags: string[];
}) {
  return api<CreateDishResponse>("/api/dishes", { method: "POST", body: payload, auth: true });
}
