import { useEffect, useMemo, useState } from "react";
import {
  Box,
  Button,
  Card,
  CardContent,
  Divider,
  List,
  ListItemButton,
  ListItemText,
  Stack,
  Typography,
  TextField,
  Chip,
  IconButton,
} from "@mui/material";
import AddRoundedIcon from "@mui/icons-material/AddRounded";
import DeleteRoundedIcon from "@mui/icons-material/DeleteRounded";
import SaveRoundedIcon from "@mui/icons-material/SaveRounded";
import AddCircleOutlineRoundedIcon from "@mui/icons-material/AddCircleOutlineRounded";
import RemoveCircleOutlineRoundedIcon from "@mui/icons-material/RemoveCircleOutlineRounded";

import {
  adminCreateDishApi,
  adminDeleteDishApi,
  adminListDishesApi,
  adminUpdateDishApi,
  type DishInputDTO,
  type RecipeStepDTO,
} from "../../features/admin/api/adminDishes.api";

import { uploadImage } from "../../features/uploads/api/upload.api"; // у тебя уже есть

type DishListItem = {
  _id: string;
  title: string;
  cuisine: string;
  tags: string[];
};

const emptyForm: DishInputDTO = {
  title: "",
  description: "",
  imageUrl: "",
  cuisine: "",
  tags: [],
  source: "manual",
  recipe: {
    serves: null,
    totalTimeMin: null,
    ingredients: [],
    steps: [],
  },
};

function parseTags(input: string): string[] {
  return input
    .split(",")
    .map((t) => t.trim())
    .filter(Boolean);
}

export function AdminDishesPage() {
  const [items, setItems] = useState<DishListItem[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const [form, setForm] = useState<DishInputDTO>(emptyForm);
  const [tagsInput, setTagsInput] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const selected = useMemo(() => items.find((x) => x._id === selectedId) ?? null, [items, selectedId]);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const res = await adminListDishesApi();
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const mapped: DishListItem[] = res.dishes.map((d: any) => ({
        _id: d._id,
        title: d.title,
        cuisine: d.cuisine,
        tags: d.tags ?? [],
      }));
      setItems(mapped);
    } catch (e: unknown) {
      setError((e as Error)?.message ?? "Failed to load");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  function onCreateNew() {
    setSelectedId(null);
    setForm(emptyForm);
    setTagsInput("");
  }

  function onSelect(item: DishListItem) {
    setSelectedId(item._id);

    // Мы не тянем getDishById для MVP — берём минимум из списка.
    // Если хочешь: легко поменяем на adminGetDishApi(item._id)
    setForm((prev) => ({
      ...prev,
      title: item.title,
      cuisine: item.cuisine,
      tags: item.tags,
      description: prev.description, // оставим как есть
      imageUrl: prev.imageUrl,
      recipe: prev.recipe,
      source: "manual",
    }));
    setTagsInput(item.tags.join(", "));
  }

  function setField<K extends keyof DishInputDTO>(key: K, value: DishInputDTO[K]) {
    setForm((p) => ({ ...p, [key]: value }));
  }

  async function onPickImage(file: File) {
    const url = await uploadImage(file);
    setField("imageUrl", url);
  }

  function addIngredient() {
    setForm((p) => ({
      ...p,
      recipe: {
        ...(p.recipe ?? { ingredients: [], steps: [] }),
        ingredients: [...((p.recipe?.ingredients ?? []) as string[]), ""],
        steps: (p.recipe?.steps ?? []) as RecipeStepDTO[],
      },
    }));
  }

  function removeIngredient(index: number) {
    setForm((p) => {
      const ing = [...(p.recipe?.ingredients ?? [])];
      ing.splice(index, 1);
      return { ...p, recipe: { ...(p.recipe ?? {}), ingredients: ing, steps: p.recipe?.steps ?? [] } };
    });
  }

  function setIngredient(index: number, value: string) {
    setForm((p) => {
      const ing = [...(p.recipe?.ingredients ?? [])];
      ing[index] = value;
      return { ...p, recipe: { ...(p.recipe ?? {}), ingredients: ing, steps: p.recipe?.steps ?? [] } };
    });
  }

  function addStep() {
    setForm((p) => ({
      ...p,
      recipe: {
        ...(p.recipe ?? { ingredients: [], steps: [] }),
        ingredients: (p.recipe?.ingredients ?? []) as string[],
        steps: [...((p.recipe?.steps ?? []) as RecipeStepDTO[]), { title: "", text: "" }],
      },
    }));
  }

  function removeStep(index: number) {
    setForm((p) => {
      const steps = [...(p.recipe?.steps ?? [])];
      steps.splice(index, 1);
      return { ...p, recipe: { ...(p.recipe ?? {}), ingredients: p.recipe?.ingredients ?? [], steps } };
    });
  }

  function setStep(index: number, patch: Partial<RecipeStepDTO>) {
    setForm((p) => {
      const steps = [...(p.recipe?.steps ?? [])];
      steps[index] = { ...steps[index], ...patch };
      return { ...p, recipe: { ...(p.recipe ?? {}), ingredients: p.recipe?.ingredients ?? [], steps } };
    });
  }

  async function onSave() {
    setSaving(true);
    setError(null);
    try {
      const tags = parseTags(tagsInput);
      const payload: DishInputDTO = {
        ...form,
        tags,
        recipe: form.recipe
          ? {
              serves: form.recipe.serves ?? null,
              totalTimeMin: form.recipe.totalTimeMin ?? null,
              ingredients: (form.recipe.ingredients ?? []).filter((x) => x.trim()),
              steps: (form.recipe.steps ?? []).filter((s) => s.title.trim() || s.text.trim()),
            }
          : null,
      };

      if (selectedId) {
        await adminUpdateDishApi(selectedId, payload);
      } else {
        await adminCreateDishApi(payload);
      }

      await load();
      onCreateNew();
    } catch (e: unknown) {
      setError((e as Error)?.message ?? "Save failed");
    } finally {
      setSaving(false);
    }
  }

  async function onDelete() {
    if (!selectedId) return;
    const ok = window.confirm("Удалить блюдо?");
    if (!ok) return;

    setSaving(true);
    setError(null);
    try {
      await adminDeleteDishApi(selectedId);
      await load();
      onCreateNew();
    } catch (e: unknown) {
      setError((e as Error)?.message ?? "Delete failed");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Box sx={{ p: { xs: 2, md: 4 }, maxWidth: 1200, mx: "auto" }}>
      <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ mb: 2 }}>
        <Typography variant="h4" fontWeight={900}>
          Admin · Dishes
        </Typography>

        <Button onClick={onCreateNew} startIcon={<AddRoundedIcon />} variant="contained">
          New dish
        </Button>
      </Stack>

      {error && (
        <Card sx={{ mb: 2, border: "1px solid rgba(255,0,0,.25)" }}>
          <CardContent>
            <Typography color="error">{error}</Typography>
          </CardContent>
        </Card>
      )}

      <Stack direction={{ xs: "column", md: "row" }} spacing={2} alignItems="stretch">
        {/* LEFT: list */}
        <Card sx={{ width: { xs: "100%", md: 380 }, flex: "0 0 auto" }}>
          <CardContent>
            <Typography fontWeight={900} sx={{ mb: 1 }}>
              Dishes
            </Typography>

            {loading ? (
              <Typography color="text.secondary">Loading...</Typography>
            ) : (
              <List dense sx={{ maxHeight: 560, overflow: "auto" }}>
                {items.map((it) => (
                  <ListItemButton
                    key={it._id}
                    selected={it._id === selectedId}
                    onClick={() => onSelect(it)}
                    sx={{ borderRadius: 2, mb: 0.5 }}
                  >
                    <ListItemText
                      primary={<Typography fontWeight={800}>{it.title}</Typography>}
                      secondary={
                        <Stack direction="row" spacing={1} alignItems="center" sx={{ mt: 0.5, flexWrap: "wrap" }}>
                          <Chip size="small" label={it.cuisine} />
                          {it.tags.slice(0, 2).map((t) => (
                            <Chip key={t} size="small" variant="outlined" label={t} />
                          ))}
                        </Stack>
                      }
                    />
                  </ListItemButton>
                ))}
              </List>
            )}
          </CardContent>
        </Card>

        {/* RIGHT: editor */}
        <Card sx={{ flex: 1, minWidth: 0 }}>
          <CardContent>
            <Typography fontWeight={900} sx={{ mb: 1 }}>
              {selected ? "Edit dish" : "Create dish"}
            </Typography>

            <Stack spacing={1.4}>
              <TextField
                label="Title"
                value={form.title}
                onChange={(e) => setField("title", e.target.value)}
                fullWidth
              />

              <TextField
                label="Cuisine"
                value={form.cuisine}
                onChange={(e) => setField("cuisine", e.target.value)}
                fullWidth
              />

              <TextField
                label="Tags (comma separated)"
                value={tagsInput}
                onChange={(e) => setTagsInput(e.target.value)}
                fullWidth
                helperText="Пример: Quick, Vegetarian, Spicy"
              />

              <TextField
                label="Description"
                value={form.description}
                onChange={(e) => setField("description", e.target.value)}
                fullWidth
                multiline
                minRows={3}
              />

              <Stack direction={{ xs: "column", sm: "row" }} spacing={1} alignItems={{ xs: "stretch", sm: "center" }}>
                <TextField
                  label="Image URL"
                  value={form.imageUrl}
                  onChange={(e) => setField("imageUrl", e.target.value)}
                  fullWidth
                />

                <Button component="label" variant="outlined">
                  Upload
                  <input
                    hidden
                    type="file"
                    accept="image/*"
                    onChange={async (e) => {
                      const file = e.target.files?.[0];
                      if (!file) return;
                      await onPickImage(file);
                      e.target.value = "";
                    }}
                  />
                </Button>
              </Stack>

              {form.imageUrl && (
                <Box sx={{ borderRadius: 3, overflow: "hidden", border: "1px solid rgba(16,17,19,0.10)" }}>
                  <img src={form.imageUrl} alt="preview" style={{ width: "100%", display: "block", maxHeight: 260, objectFit: "cover" }} />
                </Box>
              )}

              <Divider sx={{ my: 1 }} />

              <Typography fontWeight={900}>Recipe</Typography>

              <Stack direction={{ xs: "column", sm: "row" }} spacing={1}>
                <TextField
                  label="Serves"
                  type="number"
                  value={form.recipe?.serves ?? ""}
                  onChange={(e) =>
                    setForm((p) => ({
                      ...p,
                      recipe: { ...(p.recipe ?? { ingredients: [], steps: [] }), serves: e.target.value ? Number(e.target.value) : null },
                    }))
                  }
                  sx={{ width: { xs: "100%", sm: 160 } }}
                />
                <TextField
                  label="Total time (min)"
                  type="number"
                  value={form.recipe?.totalTimeMin ?? ""}
                  onChange={(e) =>
                    setForm((p) => ({
                      ...p,
                      recipe: { ...(p.recipe ?? { ingredients: [], steps: [] }), totalTimeMin: e.target.value ? Number(e.target.value) : null },
                    }))
                  }
                  sx={{ width: { xs: "100%", sm: 200 } }}
                />
              </Stack>

              {/* Ingredients */}
              <Stack spacing={1}>
                <Stack direction="row" alignItems="center" justifyContent="space-between">
                  <Typography fontWeight={800}>Ingredients</Typography>
                  <Button onClick={addIngredient} startIcon={<AddCircleOutlineRoundedIcon />} variant="text">
                    Add
                  </Button>
                </Stack>

                {(form.recipe?.ingredients ?? []).map((ing, idx) => (
                  <Stack key={idx} direction="row" spacing={1} alignItems="center">
                    <TextField
                      value={ing}
                      onChange={(e) => setIngredient(idx, e.target.value)}
                      placeholder="e.g. 500g beef"
                      fullWidth
                    />
                    <IconButton onClick={() => removeIngredient(idx)}>
                      <RemoveCircleOutlineRoundedIcon />
                    </IconButton>
                  </Stack>
                ))}
              </Stack>

              {/* Steps */}
              <Stack spacing={1}>
                <Stack direction="row" alignItems="center" justifyContent="space-between">
                  <Typography fontWeight={800}>Steps</Typography>
                  <Button onClick={addStep} startIcon={<AddCircleOutlineRoundedIcon />} variant="text">
                    Add
                  </Button>
                </Stack>

                {(form.recipe?.steps ?? []).map((s, idx) => (
                  <Card key={idx} variant="outlined" sx={{ borderRadius: 3 }}>
                    <CardContent>
                      <Stack spacing={1}>
                        <Stack direction="row" alignItems="center" justifyContent="space-between">
                          <Typography fontWeight={800}>Step {idx + 1}</Typography>
                          <IconButton onClick={() => removeStep(idx)}>
                            <RemoveCircleOutlineRoundedIcon />
                          </IconButton>
                        </Stack>

                        <TextField
                          label="Title"
                          value={s.title}
                          onChange={(e) => setStep(idx, { title: e.target.value })}
                          fullWidth
                        />
                        <TextField
                          label="Text"
                          value={s.text}
                          onChange={(e) => setStep(idx, { text: e.target.value })}
                          fullWidth
                          multiline
                          minRows={2}
                        />
                      </Stack>
                    </CardContent>
                  </Card>
                ))}
              </Stack>

              <Divider sx={{ my: 1 }} />

              <Stack direction="row" spacing={1} justifyContent="flex-end">
                {selectedId && (
                  <Button
                    onClick={onDelete}
                    startIcon={<DeleteRoundedIcon />}
                    color="error"
                    variant="outlined"
                    disabled={saving}
                  >
                    Delete
                  </Button>
                )}

                <Button
                  onClick={onSave}
                  startIcon={<SaveRoundedIcon />}
                  variant="contained"
                  disabled={saving}
                >
                  {saving ? "Saving..." : "Save"}
                </Button>
              </Stack>
            </Stack>
          </CardContent>
        </Card>
      </Stack>
    </Box>
  );
}
