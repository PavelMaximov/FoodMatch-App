import { Box, Container,} from "@mui/material";
import { Outlet } from "react-router-dom";
import { AppBackground } from "../../shared/ui/AppBackround";

export function AuthLayout() {
    return (
        <>
        <AppBackground />
        <Box
            sx={{
                minHeight: "100vh",
                display: "grid",
                placeItems: "center",
                px: 2,
                py: 6,
                backgroundColor: "#101113",
            }}
        >
          
            <Container maxWidth="sm">
                {/* Сюда рендерится LoginPage/RegisterPage */}
                <Outlet />
            </Container>
        </Box>
        </>
    );
}
