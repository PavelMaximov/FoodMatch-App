import React, { useEffect, useMemo, useRef } from "react";
import { Box, Typography } from "@mui/material";
import { motion, useAnimation } from "framer-motion";
import FavoriteIcon from '@mui/icons-material/Favorite';

type LikesHeartProps = {
  likes: number;
  size?: number; 
  onClick?: () => void;
  ariaLabel?: string;
};

function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n));
}

const MotionBox = motion(Box);


export const LikesHeart: React.FC<LikesHeartProps> = ({
  likes,
  size = 64,
  onClick,
  ariaLabel = "Total likes",
}) => {
  const prevLikesRef = useRef(likes);
  const numberAnim = useAnimation();
  const glowAnim = useAnimation();

  const safeLikes = useMemo(() => {
    if (!Number.isFinite(likes)) return 0;
    return clamp(Math.floor(likes), 0, 9999);
  }, [likes]);

  useEffect(() => {
    if (safeLikes !== prevLikesRef.current) {
      // pop эффекта для числа
      void numberAnim.start({
        scale: [1, 1.18, 1],
        transition: { duration: 0.26, ease: "easeOut" },
      });

      // лёгкая вспышка/свечение вокруг тарелки при изменении
      void glowAnim.start({
        opacity: [0, 0.35, 0],
        scale: [1, 1.06, 1],
        transition: { duration: 0.35, ease: "easeOut" },
      });

      prevLikesRef.current = safeLikes;
    }
  }, [safeLikes, numberAnim, glowAnim]);

  return (
    <MotionBox
      role={onClick ? "button" : "img"}
      aria-label={ariaLabel}
      onClick={onClick}
      sx={{
        width: size,
        height: size,
        position: "relative",
        display: "inline-grid",
        placeItems: "center",
        cursor: onClick ? "pointer" : "default",
        userSelect: "none",
        WebkitTapHighlightColor: "transparent",
      }}
      // постоянное плавание, очень деликатно
      animate={{
        y: [0, -2, 0],
        rotate: [0, -0.6, 0.6, 0],
      }}
      transition={{
        duration: 3.2,
        repeat: Infinity,
        ease: "easeInOut",
      }}
    >
      {/* Свечение при обновлении */}
      <MotionBox
        animate={glowAnim}
        initial={{ opacity: 0, scale: 1 }}
        sx={{
          position: "absolute",
          inset: -6,
          borderRadius: "50%",
          filter: "blur(10px)",
          background:
            "radial-gradient(circle, rgba(255, 95, 143, 0.55), rgba(255, 95, 143, 0) 60%)",
          pointerEvents: "none",
        }}
      />

      {/* Тарелка (SVG) */}
      <FavoriteIcon
        sx={{
          width: size * 0.6,
            height: size * 0.6,
            color: "#534253",
        }}
      />

      {/* Число по центру */}
      <MotionBox
        animate={numberAnim}
        initial={{ scale: 1 }}
        sx={{
          position: "absolute",
          inset: 0,
          display: "grid",
          placeItems: "center",
          pointerEvents: "none",
        }}
      >
        <Typography
          sx={{
            fontWeight: 800,
            lineHeight: 1,
            fontSize: Math.max(14, Math.floor(size * 0.28)),
            letterSpacing: "-0.02em",
            color: "rgba(253, 253, 253, 0.92)",
            textShadow: "0 1px 0 rgba(39, 39, 39, 0.6)",
          }}
        >
          {safeLikes}
        </Typography>
      </MotionBox>
    </MotionBox>
  );
};
