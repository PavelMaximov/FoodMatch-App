import { Badge, Box, IconButton, Paper, Typography } from "@mui/material";

import LinkRoundedIcon from "@mui/icons-material/LinkRounded";
import FavoriteBorderRoundedIcon from "@mui/icons-material/FavoriteBorderRounded";
import AddRoundedIcon from "@mui/icons-material/AddRounded";
import PersonOutlineRoundedIcon from "@mui/icons-material/PersonOutlineRounded";

export type MobileTab = "connect" | "matches" | "add" | "profile";

type Props = {
  value: MobileTab;
  onChange: (next: MobileTab) => void;
  matchesBadge?: number; 
};

const itemSx = {
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
  justifyContent: "center",
  gap: 0.5,
  minWidth: 64,
  color: "rgba(0,0,0,0.55)",
} as const;

export function MobileBottomBar({ value, onChange, matchesBadge = 0 }: Props) {
  return (
    <Paper
      elevation={0}
      sx={{
        position: "fixed",
        left: 0,
        right: 0,
        bottom: 0,
        zIndex: 50,
        borderTop: "1px solid rgba(0,0,0,0.08)",
        backgroundColor: "rgba(255,255,255,0.98)",
        pb: "env(safe-area-inset-bottom)",
      }}
    >
      <Box
        sx={{
          height: 72,
          px: 2,
          display: "grid",
          gridTemplateColumns: "1fr 1fr 1fr 1fr",
          alignItems: "center",
        }}
      >
        {/* Connect */}
        <Box sx={itemSx}>
          <IconButton
            onClick={() => onChange("connect")}
            sx={{
              backgroundColor: value === "connect" ? "rgb(250, 81, 24)" : "rgb(250, 250, 250)",
              color: value === "connect" ? "white" : "rgba(0,0,0,0.75)"
            }}
          >
            <LinkRoundedIcon />
          </IconButton>
          <Typography sx={{ fontSize: 11, lineHeight: 1 }}>
            Connect
          </Typography>
        </Box>

        {/* Matches */}
        <Box sx={itemSx}>
          <IconButton
            onClick={() => onChange("matches")}
            sx={{
              backgroundColor: value === "matches" ? "rgb(250, 81, 24)" : "rgb(250, 250, 250)",
              color: value === "matches" ? "white" : "rgba(0,0,0,0.75)"
            }}
          >
            <Badge
              color="error"
              badgeContent={matchesBadge > 0 ? matchesBadge : undefined}
              overlap="circular"
            >
              <FavoriteBorderRoundedIcon />
            </Badge>
          </IconButton>
          <Typography sx={{ fontSize: 11, lineHeight: 1 }}>
            Matches
          </Typography>
        </Box>

        {/* Add dishes (центральная) */}
        <Box sx={itemSx}>
          <IconButton
            onClick={() => onChange("add")}
            sx={{
              width: 41,
              height: 41,
              backgroundColor: value === "add" ? "rgb(250, 81, 24)" : "rgb(250, 250, 250)",
              color: value === "add" ? "white" : "rgba(0,0,0,0.75)"
              
            }}
          >
            <AddRoundedIcon />
          </IconButton>
          <Typography sx={{ fontSize: 11, lineHeight: 1 }}>
            Add dishes
          </Typography>
        </Box>

        {/* Profile */}
        <Box sx={itemSx}>
          <IconButton
            onClick={() => onChange("profile")}
            sx={{
              backgroundColor: value === "profile" ? "rgb(250, 81, 24)" : "rgb(250, 250, 250)",
              color: value === "profile" ? "white" : "rgba(0,0,0,0.75)"
            }}
          >
            <PersonOutlineRoundedIcon />
          </IconButton>
          <Typography sx={{ fontSize: 11, lineHeight: 1 }}>
            Profile
          </Typography>
        </Box>
      </Box>
    </Paper>
  );
}
