type MealDbLookupResponse = {
  meals: any[] | null;
};

export async function fetchMealById(idMeal: string) {
  const url = `https://www.themealdb.com/api/json/v1/1/lookup.php?i=${encodeURIComponent(idMeal)}`;
  const res = await fetch(url);

  if (!res.ok) throw new Error(`MealDB error: ${res.status}`);

  const data = (await res.json()) as MealDbLookupResponse;
  const meal = data.meals?.[0];
  if (!meal) return null;
  return meal;
}

export function mapMealDbToRecipe(meal: any) {
  // ингредиенты: strIngredient1..20 + strMeasure1..20
  const ingredients: string[] = [];

  for (let i = 1; i <= 20; i++) {
    const ing = String(meal[`strIngredient${i}`] ?? "").trim();
    const meas = String(meal[`strMeasure${i}`] ?? "").trim();
    if (!ing) continue;

    const line = `${meas ? `${meas} ` : ""}${ing}`.trim();
    ingredients.push(line);
  }

  // инструкции: разобьём по строкам, если строк нет — одной “простынёй”
  const raw = String(meal.strInstructions ?? "").trim();
  const parts = raw
    .split(/\r?\n+/)
    .map((s) => s.trim())
    .filter(Boolean);

  const steps =
    parts.length > 1
      ? parts.map((text, idx) => ({ title: `Step ${idx + 1}`, text }))
      : raw
      ? [{ title: "Instructions", text: raw }]
      : [];

  return { ingredients, steps };
}
