import { Box, Card, CardContent, Divider, Typography } from "@mui/material";
import type { Dish } from "../../../entities/dish/model/types";
import { MatchItem } from "./MatchItem";
import { useNavigate } from "react-router-dom";
import { LikesHeart } from "../../../shared/ui/LikesHeart";
import PeopleIcon from '@mui/icons-material/People';

type Props = {
  totalLikes: number;
  matches: Dish[];
  selectedDishId?: string;
};

function mainTag(dish: Dish) {
  return dish.tags?.[0] || "Match";
}

export function CoupleSession({ totalLikes, matches, selectedDishId }: Props) {

  const nav = useNavigate();

  return (
    <Card>
      <CardContent sx={{ p: 3 }}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1.2, mb: 1 }}>
          <Box
            sx={{
              width: 22,
              height: 22,
              borderRadius: "50%",
              background: "#FF5D1D",
              display: "grid",
              placeItems: "center",
              flex: "0 0 auto",
            }}
          >
            <PeopleIcon sx={{ color: "white", fontSize: 14 }} />
          </Box>
          <Typography
            sx={{
              fontSize: 30,
              lineHeight: 1,
              fontFamily: `"Pacifico", cursive`,
             
            }}
          >
            Couple session
          </Typography>
        </Box>
        <Typography sx={{ color: "rgba(16,17,19,0.55)", mb: 1.5 }}>
          Progress and likes are saved automatically in the browser
        </Typography>

        {/* Пилюля total likes */}
        <Box sx={{ display: "flex", alignItems: "center" }}>
          <Typography sx={{ color: "rgba(16,17,19,0.55)", }}>
          Total likes:
        </Typography>
      <LikesHeart likes={totalLikes} size={64} />
      
    </Box>

        <Divider sx={{ borderColor: "rgba(16,17,19,0.12)", mb: 2 }} />

        <Typography sx={{ fontWeight: 900, fontSize: 20, mb: 1.5 }}>
          General matches
        </Typography>

        <Box sx={{ display: "flex", flexDirection: "column", gap: 1.2 }}>
          {matches.length === 0 ? (
            <Typography sx={{ color: "rgba(16,17,19,0.55)" }}>
              When both like the same dish, it will appear here.
            </Typography>
          ) : (
            matches.slice(0, 6).map((d) => (
              <MatchItem
                key={d.id}
                tag={mainTag(d)}
                title={d.title}
                selected={d.id === selectedDishId}
                onClick={() => nav(`/recipe/${d.id}`)}
              />
            ))
          )}
        </Box>
      </CardContent>
    </Card>
  );
}
