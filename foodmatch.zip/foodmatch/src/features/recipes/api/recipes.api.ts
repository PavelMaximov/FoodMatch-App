import { api } from "../../../shared/api/http";

export type Recipe = {
  ingredients: string[];
  steps: { title: string; text: string }[];
};

export type RecipeResponse = {
  dish: {
    id: string;
    title: string;
    description: string;
    imageUrl: string;
    cuisine: string;
    tags: string[];
  };
  recipe: Recipe | null;
  source: "cache" | "mealdb" | "none";
};

export function getRecipeApi(dishId: string) {
  return api<RecipeResponse>(`/api/recipes/${dishId}`, { method: "GET", auth: true });
}
