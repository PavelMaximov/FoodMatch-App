import { api } from "../../../shared/api/http";

export type AuthTokenResponse = { token: string };

export type MeResponse = {
  user: {
    email: string;
    displayName: string;
    coupleId: string | null;
  } | null;
};

export function registerApi(payload: { email: string; password: string; displayName: string }) {
  return api<AuthTokenResponse>("/api/auth/register", { method: "POST", body: payload, auth: false });
}

export function loginApi(payload: { email: string; password: string }) {
  return api<AuthTokenResponse>("/api/auth/login", { method: "POST", body: payload, auth: false });
}

export function meApi() {
  return api<MeResponse>("/api/auth/me", { method: "GET", auth: true });
}
