import type { Dish } from "./model/types";

export const seedDishes: Dish[] = [
  {
    id: "dish_hamburger",
    title: "Hamburger",
    description: "Juicy beef patty, fresh veggies, and a soft bun.",
    imageUrl:
      "https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=1400&q=80",
    tags: ["USA", "Nourishing"],
  },
  {
    id: "dish_carbonara",
    title: "Pasta Carbonara",
    description: "Classic Italian pasta with creamy egg sauce and pancetta.",
    imageUrl:
      "https://images.unsplash.com/photo-1523986371872-9d3ba2e2f5f8?auto=format&fit=crop&w=1400&q=80",
    tags: ["Italy", "Comfort"],
  },
  {
    id: "dish_sushi",
    title: "Sushi Set",
    description: "Assorted nigiri and maki with soy sauce and ginger.",
    imageUrl:
      "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=1400&q=80",
    tags: ["Japan", "Light"],
  },
  {
    id: "dish_salad",
    title: "Greek Salad",
    description: "Tomatoes, cucumbers, olives, feta cheese, olive oil.",
    imageUrl:
      "https://images.unsplash.com/photo-1551183053-bf91a1d81141?auto=format&fit=crop&w=1400&q=80",
    tags: ["Greece", "Healthy"],
  },
];
