import { Box, Button, Divider, IconButton, TextField, Typography } from "@mui/material";
import GoogleIcon from "@mui/icons-material/Google";
import AppleIcon from "@mui/icons-material/Apple";

export function OnboardingTitle({ left, accent }: { left: string; accent: string }) {
  return (
    <Typography
      sx={{
        textAlign: "center",
        fontFamily: `"Pacifico", cursive`,
        fontSize: 32,
        lineHeight: 1.1,
        mb: 33,
        color: "white",
      }}
    >
      {left} <span style={{ color: "#FF5D1D" }}>{accent}</span>
    </Typography>
  );
}

export function OnboardingTextField(props: React.ComponentProps<typeof TextField>) {
  return (
    <TextField
      {...props}
      fullWidth
      variant="outlined"
      InputProps={{
        ...(props.InputProps ?? {}),
        sx: {
          borderRadius: 3,
          bgcolor: "white",
          ...(props.InputProps?.sx ?? {}),
        },
      }}
    />
  );
}

export function OnboardingPrimaryButton(props: React.ComponentProps<typeof Button>) {
  return (
    <Button
      {...props}
      fullWidth
      variant="contained"
      sx={{
        borderRadius: 3,
        py: 2,
        fontWeight: 900,
        textTransform: "none",
        bgcolor: "#FF5D1D", opacity: 0.95,
        "&:hover": { bgcolor: "#FF5D1D", opacity: 0.95 },
        ...(props.sx ?? {}),
      }}
    />
  );
}

export function OnboardingDivider() {
  return (
    <Divider
      sx={{
        my: 2,
        color: "rgba(255,255,255,0.45)",
        "&::before, &::after": { borderColor: "rgba(255,255,255,0.15)" },
      }}
    >
      <Typography sx={{ fontSize: 12, color: "rgba(255,255,255,0.75)" }}>
        Or log in using other services
      </Typography>
    </Divider>
  );
}

export function OnboardingOAuthRow() {
  return (
    <Box sx={{ display: "flex", gap: 2 }}>
      <IconButton
        sx={{ width: 44, height: 44, borderRadius: 8, bgcolor: "white" }}
        aria-label="Google"
      >
        <GoogleIcon />
      </IconButton>

      <IconButton
        sx={{ width: 44, height: 44, borderRadius: 8, bgcolor: "white" }}
        aria-label="Apple"
      >
        <AppleIcon />
      </IconButton>
    </Box>
  );
}

export function OnboardingBottomCTA(props: React.ComponentProps<typeof Button>) {
  return (
    <Button
      {...props}
      fullWidth
      variant="contained"
      sx={{
        mt: 2,
        borderRadius: 3,
        py: 2,
        fontWeight: 700,
        textTransform: "none",
        bgcolor: "rgba(255,255,255,0.12)",
        color: "white",
        "&:hover": { bgcolor: "rgba(255,255,255,0.16)" },
        ...(props.sx ?? {}),
      }}
    />
  );
}
