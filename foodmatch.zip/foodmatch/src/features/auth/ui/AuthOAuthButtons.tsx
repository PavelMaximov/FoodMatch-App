import { Box, Button } from "@mui/material";
import GoogleIcon from "@mui/icons-material/Google";
import AppleIcon from "@mui/icons-material/Apple";

type Props = {
  googleText?: string;
  appleText?: string;
  onGoogle?: () => void;
  onApple?: () => void;
};

export function AuthOAuthButtons({
  googleText = "Login with Google",
  appleText = "Login with Apple",
  onGoogle,
  onApple,
}: Props) {
  return (
    <Box sx={{ display: "flex", flexDirection: "column", gap: 1.4 }}>
      <Button
        variant="outlined"
        startIcon={<GoogleIcon />}
        sx={{
          borderRadius: 2,
          py: 1.1,
          borderColor: "rgba(16,17,19,0.25)",
          color: "#101113",
          fontWeight: 800,
          "&:hover": { borderColor: "rgba(16,17,19,0.35)" },
        }}
        onClick={onGoogle ?? (() => alert("Google OAuth будет добавлен позже"))}
      >
        {googleText}
      </Button>

      <Button
        variant="outlined"
        startIcon={<AppleIcon />}
        sx={{
          borderRadius: 2,
          py: 1.1,
          borderColor: "rgba(16,17,19,0.25)",
          color: "#101113",
          fontWeight: 800,
          "&:hover": { borderColor: "rgba(16,17,19,0.35)" },
        }}
        onClick={onApple ?? (() => alert("Apple OAuth будет добавлен позже"))}
      >
        {appleText}
      </Button>
    </Box>
  );
}
