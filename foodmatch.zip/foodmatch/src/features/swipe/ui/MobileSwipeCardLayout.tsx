import { Box, Chip, Typography, IconButton } from "@mui/material";
import KeyboardArrowDownRoundedIcon from "@mui/icons-material/KeyboardArrowDownRounded";
import { useMemo, useState } from "react";

type Props = {
  imageUrl?: string;
  title?: string;
  description?: string;
  tags?: string[];

  topLeftText: string;
  topRightText: string;

  onTopLeftClick?: () => void;
};

export function MobileSwipeCardLayout({
  imageUrl,
  title,
  description,
  tags = [],
  topLeftText,
  topRightText,
  onTopLeftClick,
}: Props) {
  const [expanded, setExpanded] = useState(false);

  const cleanTags = useMemo(() => tags.filter(Boolean).slice(0, 4), [tags]);

  return (
    <Box
      sx={{
        position: "relative",
    width: "100%",
    height: "100%",
    overflow: "hidden",
    borderRadius: 0,
    backgroundColor: "#111",
      }}
    >
      {/* Background image */}
      <Box
        sx={{
          position: "absolute",
          inset: 0,
          backgroundImage: imageUrl ? `url(${imageUrl})` : "none",
          backgroundSize: "cover",
          backgroundPosition: "center",
          transform: "scale(1.02)",
        }}
      />

      {/* Top pills */}
      <Box
        sx={{
          position: "absolute",
          top: 16,
          left: 16,
          right: 16,
          zIndex: 5,
          display: "flex",
          justifyContent: "space-between",
          gap: 1,
        }}
      >
        <Box
          onClick={onTopLeftClick}
          sx={{
            px: 5,
            py: 2,
            borderRadius: 999,
            border: "1px solid rgba(255,120,0,0.55)",
            color: "rgba(255,120,0,0.9)",
            backgroundColor: "rgba(0,0,0,0.25)",
            backdropFilter: "blur(8px)",
            fontWeight: 700,
            fontSize: 14,
            cursor: onTopLeftClick ? "pointer" : "default",
            userSelect: "none",
            maxWidth: "60%",
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis",
          }}
        >
          {topLeftText}
        </Box>

        <Box
          sx={{
            px: 5,
            py: 2,
            borderRadius: 999,
            border: "1px solid rgba(255,255,255,0.65)",
            color: "rgba(255,255,255,0.65)",
            
            backdropFilter: "blur(8px)",
            fontWeight: 700,
            fontSize: 14,
            userSelect: "none",
            maxWidth: "45%",
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis",
          }}
        >
          {topRightText}
        </Box>
      </Box>

      {/* Bottom gradient + content */}
      <Box
        sx={{
          position: "absolute",
          left: 0,
          right: 0,
          bottom: 0,
          zIndex: 4,
          px: 2.5,
          pt: 10,
          
          pb: 25,
          background:
            "linear-gradient(180deg, rgba(0,0,0,0) 0%, rgba(0,0,0,0.45) 25%, rgba(0,0,0,0.75) 60%, rgba(0,0,0,0.92) 100%)",
        }}
      >
        <Typography
          sx={{
            color: "white",
            fontSize: 42,
            lineHeight: 1.02,
            fontWeight: 500,
            letterSpacing: -0.5,
            mb: 1,
          }}
        >
          {title ?? ""}
        </Typography>

        {/* description + expand button */}
        <Box sx={{ display: "flex", alignItems: "flex-end", gap: 1 }}>
          <Typography
            sx={{
              color: "rgba(255,255,255,0.78)",
              fontSize: 14,
              lineHeight: 1.35,
              maxWidth: "82%",

              // Обрезка описания в свернутом виде
              display: "-webkit-box",
              WebkitBoxOrient: "vertical",
              overflow: "hidden",
              WebkitLineClamp: expanded ? 5 : 2,
            }}
          >
            {description ?? ""}
          </Typography>

          <IconButton
            onClick={() => setExpanded((v) => !v)}
            sx={{
              ml: "auto",
              width: 34,
              height: 34,
              borderRadius: 999,
              border: "1px solid rgba(255,255,255,0.22)",
              backgroundColor: "rgba(0,0,0,0.25)",
              color: "rgba(255,255,255,0.85)",
              transform: expanded ? "rotate(180deg)" : "rotate(0deg)",
              transition: "transform 180ms ease",
            }}
          >
            <KeyboardArrowDownRoundedIcon />
          </IconButton>
        </Box>

        {/* Tags */}
        <Box sx={{ display: "flex", gap: 1, mt: 1.75, flexWrap: "wrap" }}>
          {cleanTags.map((t) => (
            <Chip
              key={t}
              label={t}
              variant="outlined"
              sx={{
                height: 28,
                borderRadius: 999,
                borderColor: "rgba(255,255,255,0.22)",
                color: "rgba(255,255,255,0.75)",
                backgroundColor: "rgba(0,0,0,0.20)",
                backdropFilter: "blur(8px)",
                "& .MuiChip-label": { px: 1.2, fontSize: 12, fontWeight: 600 },
              }}
            />
          ))}
        </Box>
      </Box>
    </Box>
  );
}
