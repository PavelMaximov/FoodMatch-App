import { Box, Button, TextField, Typography, useMediaQuery } from "@mui/material";
import { useTheme } from "@mui/material/styles";
import { useState } from "react";
import { Link as RouterLink } from "react-router-dom";

import { AuthCard } from "../../features/auth/ui/AuthCard";
import { PrimaryButton } from "../../shared/ui/PrimaryButton";

import { OnboardingLayout } from "../../features/auth/ui/OnboardingLayout";
import {
  OnboardingTitle,
  OnboardingTextField,
  OnboardingPrimaryButton,
  OnboardingBottomCTA,
} from "../../features/auth/ui/OnboardingAuthUI";

import BG_URL from "../../assets/media/onboarding.jpg";

export function ForgotPasswordPage() {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("md"));

  if (isMobile) {
    return <MobileForgotView />;
  }

  return <DesktopForgotView />;
}

// --------------------
// DESKTOP 
// --------------------
function DesktopForgotView() {
  const [email, setEmail] = useState("");

  return (
    <AuthCard>
      <Typography sx={{ fontFamily: `"Pacifico", cursive`, fontSize: 34, lineHeight: 1, mb: 2 }}>
        Forgot password
      </Typography>

      <Typography sx={{ color: "rgba(16,17,19,0.60)", mb: 2.5 }}>
        Пока это заглушка. Позже мы добавим отправку письма через backend.
      </Typography>

      <Box sx={{ display: "flex", flexDirection: "column", gap: 1.6 }}>
        <TextField
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="* Email"
          InputProps={{ sx: { borderRadius: 3 } }}
        />

        <PrimaryButton disabled sx={{ mt: 0.5 }}>
          Send reset link (soon)
        </PrimaryButton>

        <Button
          component={RouterLink}
          to="/login"
          variant="outlined"
          sx={{
            py: 1.25,
            borderRadius: 999,
            fontWeight: 900,
            borderColor: "rgba(73,66,108,0.55)",
            color: "#49426C",
            "&:hover": { borderColor: "rgba(73,66,108,0.75)" },
          }}
        >
          Back to login
        </Button>
      </Box>
    </AuthCard>
  );
}

// --------------------
// MOBILE 
// --------------------
function MobileForgotView() {
  const [email, setEmail] = useState("");

  return (
    <OnboardingLayout
      backgroundUrl={BG_URL}
      titleTop="Foodmatch"
      subtitleTop="Enter your email and we’ll send you a reset link."
    >
      <OnboardingTitle left="Reset your" accent="Password" />

      <Box sx={{ display: "flex", flexDirection: "column", gap: 1.4 }}>
        <OnboardingTextField
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="* Email"
          autoComplete="email"
        />

        <OnboardingPrimaryButton disabled>
          Send reset link (soon)
        </OnboardingPrimaryButton>

        <RouterLink to="/login" style={{ textDecoration: "none" }}>
          <OnboardingBottomCTA >
            Back to <span style={{ color: "#FF5D1D", marginLeft: "6px" }}>Login</span>
          </OnboardingBottomCTA>
        </RouterLink>

        <Typography
          sx={{
            mt: 0.6,
            textAlign: "center",
            color: "rgba(255,255,255,0.6)",
            fontSize: 12,
            lineHeight: 1.35,
          }}
        >
          We’ll add the real email flow when backend endpoint is ready.
        </Typography>
      </Box>
    </OnboardingLayout>
  );
}
