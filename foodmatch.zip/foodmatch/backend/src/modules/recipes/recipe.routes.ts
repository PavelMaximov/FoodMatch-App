import { Router } from "express";
import { requireAuth } from "../../middlewares/auth.middleware.js";
import { getRecipeByDishId } from "./recipe.controller.js";

export const recipeRouter = Router();

recipeRouter.get("/:dishId", getRecipeByDishId);