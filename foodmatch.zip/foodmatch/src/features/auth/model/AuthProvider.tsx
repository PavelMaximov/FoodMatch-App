import { createContext, useEffect, useState } from "react";
import type { ReactNode } from "react";
import { loginApi, meApi, registerApi } from "../api/auth.api";

type User = {
  email: string;
  displayName: string;
  coupleId: string | null;
};

export type AuthState = {
  user: User | null;
  isLoading: boolean;
  isAuthed: boolean;
  login: (payload: { email: string; password: string }) => Promise<void>;
  register: (payload: { email: string; password: string; displayName: string }) => Promise<void>;
  logout: () => void;
  refreshMe: () => Promise<void>;
};

export const AuthContext = createContext<AuthState | null>(null);

const TOKEN_KEY = "foodmatch_token";

function getToken() {
  return localStorage.getItem(TOKEN_KEY);
}
function setToken(token: string) {
  localStorage.setItem(TOKEN_KEY, token);
}
function clearToken() {
  localStorage.removeItem(TOKEN_KEY);
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  async function refreshMe() {
    try {
      const res = await meApi();
      setUser(res.user);
    } catch {
      setUser(null);
      clearToken();
    }
  }

  useEffect(() => {
    const token = getToken();
    if (!token) {
      setIsLoading(false);
      return;
    }

    (async () => {
      await refreshMe();
      setIsLoading(false);
    })();
  }, []);

  async function login(payload: { email: string; password: string }) {
    setIsLoading(true);
    try {
      const res = await loginApi(payload);
      setToken(res.token);
      await refreshMe();
    } finally {
      setIsLoading(false);
    }
  }

  async function register(payload: { email: string; password: string; displayName: string }) {
    setIsLoading(true);
    try {
      const res = await registerApi(payload);
      setToken(res.token);
      await refreshMe();
    } finally {
      setIsLoading(false);
    }
  }

  function logout() {
    clearToken();
    setUser(null);
  }

  const value: AuthState = {
    user,
    isLoading,
    isAuthed: Boolean(user),
    login,
    register,
    logout,
    refreshMe,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
