import type { Response } from "express";
import { z } from "zod";
import type { AuthRequest } from "../../middlewares/auth.middleware.js";
import { User } from "../users/user.model.js";
import { Couple } from "../couples/couple.model.js";
import { Dish } from "../dishes/dish.model.js";
import { Swipe } from "./swipe.model.js";

const recordSchema = z.object({
  dishId: z.string().min(10),
  action: z.enum(["like", "dislike"]),
});

export async function recordSwipe(req: AuthRequest, res: Response) {
  const parsed = recordSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ message: "Invalid input" });

  const userId = req.userId!;
  const user = await User.findById(userId);
  if (!user) return res.status(404).json({ message: "User not found" });
  if (!user.coupleId) return res.status(400).json({ message: "User is not in a couple session" });

  const dish = await Dish.findById(parsed.data.dishId);
  if (!dish) return res.status(404).json({ message: "Dish not found" });

  // upsert: если уже свайпал — обновляем action
  await Swipe.findOneAndUpdate(
    { userId, dishId: dish._id },
    { userId, coupleId: user.coupleId, dishId: dish._id, action: parsed.data.action },
    { upsert: true, new: true }
  );

  return res.json({ ok: true });
}

export async function myStats(req: AuthRequest, res: Response) {
  const userId = req.userId!;
  const user = await User.findById(userId);
  if (!user) return res.status(404).json({ message: "User not found" });
  if (!user.coupleId) return res.json({ likes: 0, dislikes: 0 });

  const [likes, dislikes] = await Promise.all([
    Swipe.countDocuments({ userId, coupleId: user.coupleId, action: "like" }),
    Swipe.countDocuments({ userId, coupleId: user.coupleId, action: "dislike" }),
  ]);

  return res.json({ likes, dislikes });
}

export async function matches(req: AuthRequest, res: Response) {
  const userId = req.userId!;
  const user = await User.findById(userId);
  if (!user) return res.status(404).json({ message: "User not found" });
  if (!user.coupleId) return res.json({ matches: [] });

  const couple = await Couple.findById(user.coupleId).lean();
  if (!couple) return res.status(404).json({ message: "Couple not found" });

  if (couple.members.length < 2) {
    return res.json({ matches: [] }); // второй юзер еще не подключился
  }

  const [u1, u2] = couple.members.map(String);

  const [likes1, likes2] = await Promise.all([
    Swipe.find({ userId: u1, coupleId: couple._id, action: "like" }).select("dishId").lean(),
    Swipe.find({ userId: u2, coupleId: couple._id, action: "like" }).select("dishId").lean(),
  ]);

  const set1 = new Set(likes1.map((x) => String(x.dishId)));
  const commonIds = likes2.map((x) => String(x.dishId)).filter((id) => set1.has(id));

  const dishes = await Dish.find({ _id: { $in: commonIds } })
    .select("title description imageUrl cuisine tags")
    .limit(50)
    .lean();

  return res.json({ matches: dishes });
}
