import { Box, Divider, TextField, Typography, FormControlLabel, Checkbox, useMediaQuery } from "@mui/material";
import { useTheme } from "@mui/material/styles";
import { useState } from "react";
import { useNavigate, Link as RouterLink } from "react-router-dom";

import { useAuth } from "../../features/auth/model/useAuth";
import { AuthCard } from "../../features/auth/ui/AuthCard";
import { AuthOAuthButtons } from "../../features/auth/ui/AuthOAuthButtons";
import { PrimaryButton } from "../../shared/ui/PrimaryButton";

import { OnboardingLayout } from "../../features/auth/ui/OnboardingLayout";
import {
  OnboardingTitle,
  OnboardingTextField,
  OnboardingPrimaryButton,
  OnboardingDivider,
  OnboardingOAuthRow,
  OnboardingBottomCTA,
} from "../../features/auth/ui/OnboardingAuthUI";

import BG_URL from "../../assets/media/onboarding.jpg";



export function LoginPage() {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("md"));

  if (isMobile) {
    return <MobileLoginView />;
  }

  return <DesktopLoginView />;
}

// --------------------
// DESKTOP 
// --------------------
function DesktopLoginView() {
  const { login, isLoading } = useAuth();
  const nav = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(true);

  async function onSubmit() {
    await login({ email, password });
    nav("/swipe");
  }

  return (
    <AuthCard>
      
      <Typography sx={{ fontFamily: `"Pacifico", cursive`, fontSize: 34, lineHeight: 1, mb: 2.5 }}>
        Login to <span style={{ color: "#FF5D1D" }}>Foodmatch</span>
      </Typography>

      <AuthOAuthButtons />

      <Divider sx={{ my: 2.6, color: "rgba(16,17,19,0.30)" }}>Or</Divider>

      <Box sx={{ display: "flex", flexDirection: "column", gap: 1.6 }}>
        <TextField
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="* Email"
          InputProps={{ sx: { borderRadius: 3 } }}
        />

        <TextField
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="* Password"
          type="password"
          InputProps={{ sx: { borderRadius: 3 } }}
        />

        <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mt: 0.5 }}>
          <FormControlLabel
            control={<Checkbox checked={remember} onChange={(e) => setRemember(e.target.checked)} />}
            label={<Typography sx={{ fontWeight: 700 }}>Remember me</Typography>}
          />

          <Typography
            component={RouterLink}
            to="/forgot-password"
            sx={{ fontWeight: 800, color: "#49426C", textDecoration: "none" }}
          >
            Forgot password?
          </Typography>
        </Box>

        <PrimaryButton onClick={onSubmit} disabled={isLoading} sx={{ mt: 1 }}>
          Login
        </PrimaryButton>

        <Typography sx={{ textAlign: "center", mt: 1.5, fontWeight: 800, color: "#49426C" }}>
          <Typography component={RouterLink} to="/register" sx={{ color: "inherit", textDecoration: "none" }}>
            Register on Foodmatch.com
          </Typography>
        </Typography>

        <Typography sx={{ mt: 2, fontWeight: 900 }}>Have questions?</Typography>
      </Box>
    </AuthCard>
  );
}

// --------------------
// MOBILE 
// --------------------
function MobileLoginView() {
  const { login, isLoading } = useAuth();
  const nav = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(true);

  async function onSubmit() {
    await login({ email, password });
    nav("/swipe");
  }

  return (
    <OnboardingLayout
      backgroundUrl={BG_URL}
      titleTop="Foodmatch"
      subtitleTop="Choose a user, swap dishes one by one, and find flavor matches. You can add your own ideas and save them to the shared deck."
    >
      <OnboardingTitle left="Login to" accent="Foodmatch" />

      <Box sx={{ display: "flex", flexDirection: "column", gap: 1.4 }}>
        <OnboardingTextField
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="* Email"
          autoComplete="email"
        />

        <OnboardingTextField
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="* Password"
          type="password"
          autoComplete="current-password"
        />

        <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mt: 0.4 }}>
          <FormControlLabel
            control={
              <Checkbox
                checked={remember}
                onChange={(e) => setRemember(e.target.checked)}
                sx={{ color: "white" }}
              />
            }
            label={<Typography sx={{ color: "white", fontWeight: 800 }}>Remember me</Typography>}
          />

          <Typography
            component={RouterLink}
            to="/forgot-password"
            sx={{ color: "white", fontWeight: 800, textDecoration: "underline" }}
          >
            Forgot password?
          </Typography>
        </Box>

        <OnboardingPrimaryButton onClick={onSubmit} disabled={isLoading}>
          Login
        </OnboardingPrimaryButton>

        <OnboardingDivider />
        <OnboardingOAuthRow />

        <RouterLink to="/register" style={{ textDecoration: "none" }}>
          <OnboardingBottomCTA>
            Still have no account? <span style={{ color: "#FF5D1D", marginLeft: "6px" }}> Sign up</span>
          </OnboardingBottomCTA>
        </RouterLink>
      </Box>
    </OnboardingLayout>
  );
}
