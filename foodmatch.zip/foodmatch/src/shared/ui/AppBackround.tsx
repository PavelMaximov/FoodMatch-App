import { Box } from "@mui/material";

export function AppBackground() {
  return (
    <Box
      sx={{
        position: "fixed",
        inset: 0,
        zIndex: -1,
        overflow: "hidden",
        background: "radial-gradient(1200px 700px at 20% 10%, rgba(74,66,108,0.35), transparent 55%), radial-gradient(1100px 650px at 80% 90%, rgba(61, 57, 55, 0.22), transparent 55%), #07080C",
      }}
    >
      {/* “блоб” 1 */}
      <Box
        sx={{
          position: "absolute",
          width: 520,
          height: 520,
          left: "-120px",
          top: "120px",
          borderRadius: "50%",
          background: "rgba(73,66,108,0.25)",
          filter: "blur(90px)",
          opacity: 0.55,
          pointerEvents: "none",
        }}
      />
      {/* “блоб” 2 */}
      <Box
        sx={{
          position: "absolute",
          width: 600,
          height: 600,
          right: "-200px",
          top: "-160px",
          borderRadius: "50%",
          background: "rgba(251,75,17,0.25)",
          filter: "blur(90px)",
          opacity: 0.45,
          pointerEvents: "none",
        }}
      />
      {/* “блоб” 3 */}
      <Box
        sx={{
          position: "absolute",
          width: 560,
          height: 560,
          right: "320px",
          bottom: "-240px",
          borderRadius: "50%",
          background: "rgba(42, 125, 125, 0.28)",
          filter: "blur(90px)",
          opacity: 0.40,
          pointerEvents: "none",
        }}
      />
    </Box>
  );
}
