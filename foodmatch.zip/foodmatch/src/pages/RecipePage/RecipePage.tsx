import { Grid, Alert, CircularProgress } from "@mui/material";
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

import { RecipeCard } from "./RecipeCard";
import { CoupleSession } from "../../features/matches/ui/CoupleSession";

import { getRecipeApi, type RecipeResponse } from "../../features/recipes/api/recipes.api";
import { matchesApi, mySwipeStatsApi } from "../../features/swipe/api/swipes.api";

import type { Dish } from "../../entities/dish/model/types";
import type { DishDTO } from "../../features/dishes/api/dishes.api";

function mapDish(dto: DishDTO): Dish {
  return {
    id: dto._id,
    title: dto.title,
    description: dto.description,
    imageUrl: dto.imageUrl,
    tags: [dto.cuisine, ...dto.tags],
    createdBy: dto.createdBy ?? undefined,
  };
}

export function RecipePage() {
  const { dishId } = useParams();

  const [recipeData, setRecipeData] = useState<RecipeResponse | null>(null);
  const [loadingRecipe, setLoadingRecipe] = useState(true);
  const [recipeErr, setRecipeErr] = useState<string | null>(null);

  const [likesCount, setLikesCount] = useState(0);
  const [matches, setMatches] = useState<Dish[]>([]);

  async function loadMatchesAndStats() {
    try {
      const [stats, m] = await Promise.all([mySwipeStatsApi(), matchesApi()]);
      setLikesCount(stats.likes);

      const normalized: Dish[] = (m.matches as Array<DishDTO | Dish>).map((x) => {
        if (x && typeof x === "object" && "_id" in x) return mapDish(x as DishDTO);
        return x as Dish;
      });

      setMatches(normalized);
    } catch {
      // если не в паре — молчим
    }
  }

  useEffect(() => {
    const handler = () => {
      setMatches([]);
      loadMatchesAndStats();
    };
    window.addEventListener("foodmatch:sessionChanged", handler);
    return () => window.removeEventListener("foodmatch:sessionChanged", handler);
  }, []);

  useEffect(() => {
    loadMatchesAndStats();
  }, []);

  useEffect(() => {
    if (!dishId) return;

    setLoadingRecipe(true);
    setRecipeErr(null);

    getRecipeApi(dishId)
      .then(setRecipeData)
      .catch((e: Error) => setRecipeErr(e?.message ?? "Failed to load recipe"))
      .finally(() => setLoadingRecipe(false));
  }, [dishId]);

  if (!dishId) return <Alert severity="warning">No dishId</Alert>;
  if (loadingRecipe) return <CircularProgress />;
  if (recipeErr) return <Alert severity="error">{recipeErr}</Alert>;
  if (!recipeData) return <Alert severity="warning">Recipe not found</Alert>;

  return (
    <Grid container spacing={3}>
      <Grid size={{ xs: 12, md: 7 }}>
        <RecipeCard data={recipeData} />
      </Grid>

      <Grid size={{ xs: 12, md: 5 }}>
        <CoupleSession totalLikes={likesCount} matches={matches} selectedDishId={dishId} />
      </Grid>
    </Grid>
  );
}
