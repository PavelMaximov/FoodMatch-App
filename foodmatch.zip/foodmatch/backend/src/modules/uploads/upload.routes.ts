import { Router } from "express";
import multer from "multer";
import path from "path";
import { requireAuth } from "../../middlewares/auth.middleware.js";

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, "uploads"),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const safeExt = ext || ".jpg";
    cb(null, `${Date.now()}-${Math.random().toString(16).slice(2)}${safeExt}`);
  },
});

function imageFilter(_req: any, file: any, cb: any) {
  if (!file.mimetype?.startsWith("image/")) {
    return cb(new Error("Only images are allowed"), false);
  }
  cb(null, true);
}

const upload = multer({
  storage,
  fileFilter: imageFilter,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
});

export const uploadRouter = Router();

// field name = "file"
uploadRouter.post("/", requireAuth, upload.single("file"), (req, res) => {
  const file = req.file;
  if (!file) return res.status(400).json({ message: "No file uploaded" });

  // полный URL для фронта
  const url = `${req.protocol}://${req.get("host")}/uploads/${file.filename}`;
  return res.json({ url });
});
