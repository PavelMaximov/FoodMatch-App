import { useEffect, useMemo, useState } from "react";
import type { Dish } from "../../../../entities/dish/model/types";
import { readJSON, writeJSON } from "../../../../shared/utils/storage";

type SwipeAction = "like" | "dislike";

type Options = {
  onSwipe?: (payload: { dish: Dish; action: SwipeAction }) => void | Promise<void>;
};

type HistoryItem = {
  dishId: string;
  action: SwipeAction;
};

type SwipeState = {
  currentIndex: number;
  history: HistoryItem[];
  lastDishId: string | null; // ✅ чтобы восстановиться по id
};

const STORAGE_KEY = "foodmatch_swipe_v1";

function defaultState(): SwipeState {
  return { currentIndex: 0, history: [], lastDishId: null };
}

export function useSwipeDeck(dishes: Dish[], options?: Options) {
  // 1) читаем как есть, НЕ завязываемся на dishes.length (он 0 на первом рендере)
  const [state, setState] = useState<SwipeState>(() => readJSON(STORAGE_KEY, defaultState()));

  // 2) когда блюда загрузились/изменились — нормализуем текущую позицию
  useEffect(() => {
    if (!dishes.length) return;

    setState((prev) => {
      // a) если есть lastDishId — найдём его индекс в новом массиве
      if (prev.lastDishId) {
        const idx = dishes.findIndex((d) => d.id === prev.lastDishId);
        if (idx !== -1) {
          // idx — это последняя просмотренная карточка
          // значит следующая карточка = idx + 1
          const nextIndex = Math.min(idx + 1, dishes.length); // dishes.length = "finished"
          if (nextIndex !== prev.currentIndex) {
            return { ...prev, currentIndex: nextIndex };
          }
          return prev;
        }
        // если lastDishId больше нет — упадём на безопасный индекс ниже
      }

      // b) fallback: просто ограничим currentIndex по длине
      const safeIndex = Math.min(prev.currentIndex, dishes.length);
      if (safeIndex !== prev.currentIndex) {
        return { ...prev, currentIndex: safeIndex };
      }
      return prev;
    });
  }, [dishes]);

  // 3) сохраняем в localStorage
  useEffect(() => {
    writeJSON(STORAGE_KEY, state);
  }, [state]);

  // 4) сброс при смене сессии (reset/leave)
  useEffect(() => {
    const handler = () => setState(defaultState());
    window.addEventListener("foodmatch:sessionChanged", handler);
    return () => window.removeEventListener("foodmatch:sessionChanged", handler);
  }, []);

  const currentDish = dishes[state.currentIndex] ?? null;
  const nextDish = dishes[state.currentIndex + 1] ?? null;
  const isFinished = dishes.length === 0 || state.currentIndex >= dishes.length;

  const totalLikes = useMemo(() => {
    return state.history.filter((h) => h.action === "like").length;
  }, [state.history]);

  function swipe(action: SwipeAction) {
    setState((prev) => {
      const dish = dishes[prev.currentIndex];
      if (!dish) return prev;

      // lastDishId = то, что мы только что свайпнули
      const next: SwipeState = {
        currentIndex: prev.currentIndex + 1,
        history: [...prev.history, { dishId: dish.id, action }],
        lastDishId: dish.id,
      };

      options?.onSwipe?.({ dish, action });
      return next;
    });
  }

  function previous() {
    setState((prev) => {
      if (prev.history.length === 0) return prev;

      const nextHistory = prev.history.slice(0, -1);
      const nextIndex = Math.max(prev.currentIndex - 1, 0);

      // вычислим lastDishId: это dishId последнего элемента истории после undo
      const newLastDishId = nextHistory.length ? nextHistory[nextHistory.length - 1].dishId : null;

      return {
        currentIndex: nextIndex,
        history: nextHistory,
        lastDishId: newLastDishId,
      };
    });
  }

  function reset() {
    setState(defaultState());
  }

  const canGoBack = state.history.length > 0;
  const canSwipe = Boolean(currentDish) && !isFinished;

  return {
    currentDish,
    nextDish,
    totalLikes,
    isFinished,
    canGoBack,
    canSwipe,
    swipe,
    previous,
    reset,
  };
}

export type SwipeDeck = ReturnType<typeof useSwipeDeck>;
