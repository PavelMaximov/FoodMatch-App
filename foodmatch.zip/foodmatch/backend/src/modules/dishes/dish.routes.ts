import { Router } from "express";
import { requireAdmin } from "../../middlewares/requireAdmin.js";
import {
  listDishes,
  createDish,
  getDishById,
  updateDishById,
  deleteDishById,
} from "./dish.controller.js";

export const dishRouter = Router();

dishRouter.get("/", listDishes);
dishRouter.get("/:id", getDishById);

dishRouter.post("/", requireAdmin, createDish);
dishRouter.patch("/:id", requireAdmin, updateDishById);
dishRouter.delete("/:id", requireAdmin, deleteDishById);
