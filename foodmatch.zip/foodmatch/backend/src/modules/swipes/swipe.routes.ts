import { Router } from "express";
import { requireAuth } from "../../middlewares/auth.middleware.js";
import { recordSwipe, myStats, matches } from "./swipe.controller";

export const swipeRouter = Router();

swipeRouter.post("/", requireAuth, recordSwipe);
swipeRouter.get("/me/stats", requireAuth, myStats);
swipeRouter.get("/matches", requireAuth, matches);
