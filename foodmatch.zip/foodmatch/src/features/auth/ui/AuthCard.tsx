import { Card, CardContent } from "@mui/material";
import type { ReactNode } from "react";

type Props = {
  children: ReactNode;
};

export function AuthCard({ children }: Props) {
  return (
    <Card
      sx={{
        borderRadius: 6,
        boxShadow: "0 18px 60px rgba(0,0,0,0.35)",
      }}
    >
      <CardContent sx={{ p: { xs: 3, sm: 4 } }}>{children}</CardContent>
    </Card>
  );
}
