import { Box, Button, Typography } from "@mui/material";
import logoFoodmatch from "../../assets/media/logofmwhitenotext.png";
import { useMemo, useState } from "react";
import { ConnectSessionDialog } from "../../features/couples/ui/ConnectSessionDialog";
// import { useAuth } from "../../features/auth/model/useAuth";
import { useCoupleSession } from "../../features/couples/model/useCoupleSession";

 function SessionBadge({ text }: { text: string }) {
  return (
    <Box
      sx={{
        px: 2,
                py: 0.9,
                borderRadius: 999,
                background: "rgba(255,255,255,0.10)",
                border: "1px solid rgba(255,255,255,0.18)",
                color: "white",
                fontWeight: 700,
                fontSize: "0.875rem",
                lineHeight: 1.75,
                maxWidth: 280,
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
      }}
    >
      {text}
    </Box>
  );
}

export function Header() {
    // const { user } = useAuth();
    const { session, loading } = useCoupleSession();
    const [open, setOpen] = useState(false);

   const sessionText = useMemo(() => {
    if (loading) return "Session...";
    if (session.status === "none") return "Not connected";
    const count = session.members.length;
    if (count >= 2) return "Connected 2/2";
    return "Waiting 1/2";
  }, [session, loading]);


    return (
        <>
        <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <Box>
                <Box sx={{ display: "flex", alignItems: "center", gap: 1, mb: 1 }}>
                    <img src={logoFoodmatch} alt="Foodmatch Logo" height={38} />
                    <Typography
                        variant="h4"
                        sx={{ color: "white", 
                          fontWeight: 400, 
                          lineHeight: 1, 
                          fontFamily: `"Pacifico", cursive`,
                        fontSize: { xs: 30, sm: 40 }, }}
                    >
                        Foodmatch
                    </Typography>
                    <Typography
                        variant="h4"
                        sx={{ color: "white", mt: 0.5, fontWeight: 400 }}
                    >
                        - swap dishes together
                    </Typography>
                </Box>
                <Typography sx={{ color: "rgba(255,255,255,0.68)", mt: 0.5 }}>
                    Choose a user, swap dishes one by one, and find flavor matches.
                    You can add your own ideas and save them to the shared deck.
                </Typography>

            </Box>
            <Box sx={{ display: "flex", flexWrap: "wrap", ml: 2, gap: 2, alignItems: "center", flexShrink: 0, }}>
          {/* {user?.displayName && (
            <Box
              sx={{
                px: 2,
                py: 0.9,
                borderRadius: 999,
                background: "rgba(255,255,255,0.10)",
                border: "1px solid rgba(255,255,255,0.18)",
                color: "white",
                fontWeight: 700,
                fontSize: "0.875rem",
                lineHeight: 1.75,
                maxWidth: 280,
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
              }}
              title={user.displayName}
            >
             You: {user.displayName}
            </Box> */}
          {/* )} */}
          
            <SessionBadge text={sessionText} />

          <Button
            variant="outlined"
           sx={{
                    color: "rgba(251,75,17,0.5)",
                    backgroundColor: "rgba(251,75,17,0.08)",
                    borderColor: "rgba(251,75,17,0.22)",
                    borderRadius: 2,
                    px: 3,
                    py: 1,
                    "&:hover": { borderColor: "rgba(251,75,17,0.9)", color: "rgba(251,75,17,0.9)", },
                }}
            onClick={() => setOpen(true)}
          >
            Connect session
          </Button>
        </Box>
      </Box>

      <ConnectSessionDialog open={open} onClose={() => setOpen(false)} />
      
        
        </>
    );
}
