import type { Response } from "express";
import type { AuthRequest } from "../../middlewares/auth.middleware.js";
import { isValidObjectId } from "mongoose";
import { Dish } from "../dishes/dish.model.js";
import { fetchMealById, mapMealDbToRecipe } from "../../services/mealdb.service.js";

export async function getRecipeByDishId(req: AuthRequest, res: Response) {
  try {
    const { dishId } = req.params;

    if (!isValidObjectId(dishId)) {
      return res.status(400).json({ message: "Invalid dishId" });
    }

    const dish = await Dish.findById(dishId);
    if (!dish) return res.status(404).json({ message: "Dish not found" });

    if (dish.recipe) {
      return res.json({
        dish: {
          id: String(dish._id),
          title: dish.title,
          description: dish.description,
          imageUrl: dish.imageUrl,
          cuisine: dish.cuisine,
          tags: dish.tags ?? [],
        },
        recipe: dish.recipe,
        source: "cache",
      });
    }

    if (dish.source === "mealdb" && dish.externalId) {
      const meal = await fetchMealById(dish.externalId);
      if (!meal) return res.status(404).json({ message: "Recipe not found in MealDB" });

      const recipe = mapMealDbToRecipe(meal);
      dish.recipe = recipe as any;
      await dish.save();

      return res.json({
        dish: {
          id: String(dish._id),
          title: dish.title,
          description: dish.description,
          imageUrl: dish.imageUrl,
          cuisine: dish.cuisine,
          tags: dish.tags ?? [],
        },
        recipe,
        source: "mealdb",
      });
    }

    // user блюдо — рецепта пока нет
    return res.json({
      dish: {
        id: String(dish._id),
        title: dish.title,
        description: dish.description,
        imageUrl: dish.imageUrl,
        cuisine: dish.cuisine,
        tags: dish.tags ?? [],
      },
      recipe: null,
      source: "none",
    });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ message: "Internal Server Error" });
  }
}
