import type { Dish } from "../../../entities/dish//model/types";
import { readJSON, writeJSON } from "../../../shared/utils/storage";

const STORAGE_KEY = "foodmatch_user_dishes_v1";

export function loadUserDishes(): Dish[] {
  return readJSON<Dish[]>(STORAGE_KEY, []);
}

export function saveUserDishes(dishes: Dish[]): void {
  writeJSON(STORAGE_KEY, dishes);
}
