import dotenv from "dotenv";
dotenv.config();

export const env = {
  port: Number(process.env.PORT ?? 4000),
  mongoUri: process.env.MONGO_URI ?? "",
  jwtSecret: process.env.JWT_SECRET ?? "",
  jwtExpiresIn: process.env.JWT_EXPIRES_IN ?? "7d",

  adminEmail: process.env.ADMIN_EMAIL ?? "admin",
  adminPassword: process.env.ADMIN_PASSWORD ?? "admin",
  adminCookieSecret: process.env.ADMIN_COOKIE_SECRET ?? "change_me_please",
};
