import { api } from "../../../shared/api/http";
import type { DishDTO } from "../../dishes/api/dishes.api";

export function recordSwipeApi(payload: { dishId: string; action: "like" | "dislike" }) {
  return api<{ ok: true }>("/api/swipes", { method: "POST", body: payload, auth: true });
}

export function mySwipeStatsApi() {
  return api<{ likes: number; dislikes: number }>("/api/swipes/me/stats", { method: "GET", auth: true });
}

export function matchesApi() {
  return api<{ matches: DishDTO[] }>("/api/swipes/matches", { method: "GET", auth: true });
}
